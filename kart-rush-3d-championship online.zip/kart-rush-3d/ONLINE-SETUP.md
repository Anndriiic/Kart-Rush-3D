# Put Kart Rush online (no installs on the event laptop)

You'll end up with a link like **https://kart-rush.onrender.com**.
The big-screen laptop only needs a web browser. Phones can use Wi-Fi or mobile data.

## A. Upload the game to GitHub (free, ~5 min)
1. Go to **github.com** and create a free account (or sign in).
2. Click **+** (top right) → **New repository**. Name it `kart-rush`, choose **Private**, click **Create repository**.
3. On the new page, click **"uploading an existing file"**.
4. Open the unzipped `kart-rush-3d` folder on your computer, select **everything inside it**
   (`server.js`, `package.json`, `render.yaml`, the `public` and `vendor` folders, etc.) and drag it all into the browser.
   Upload the *contents* of the folder, not the folder itself, so `server.js` sits at the top level.
5. Wait for the files to finish uploading, then click **Commit changes**.

## B. Host it on Render (free, ~5 min)
1. Go to **render.com** → **Get Started** → sign up **with GitHub**.
2. Click **New +** → **Web Service** → connect GitHub and pick the `kart-rush` repository.
3. Fill in:
   - **Region:** Singapore
   - **Runtime:** Node
   - **Build command:** `npm install`
   - **Start command:** `node server.js`
   - **Instance type:** Free
4. Click **Create Web Service** and wait 1–3 minutes until it says **Live**.
5. Your link appears at the top (e.g. `https://kart-rush.onrender.com`).

## C. Use it
- **Big screen:** open `https://<your-link>/host` in Chrome on the projector laptop. Press F11 (Windows) or Ctrl+Cmd+F (Mac) for full screen.
- **Players:** scan the QR code. It automatically points to your online link.
- **Tilt steering** now works too (needs the https link).

## Good to know (free plan)
- The free server **sleeps after 15 minutes with nobody using it**. The first visit wakes it up, which can take about a minute.
  **Open the /host page 5–10 minutes before the event.** While that page is open, it keeps the server awake.
- Render may occasionally restart free servers. If that happens mid-event, the big screen reconnects automatically and
  keeps the championship progress. The room code may change, though, so players would need to re-scan the QR code.
- For the event day itself, you can switch the service to Render's cheapest paid instance in **Settings → Instance type**
  so it never sleeps or restarts unexpectedly, then switch back to Free afterwards.
- Everyone needs internet: the laptop and the phones (Wi-Fi or mobile data).
