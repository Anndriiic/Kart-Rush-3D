// Phone-side kart customiser: live 3D preview + option tabs. Talks to the controller via window.KR.
import * as THREE from 'three';
import { buildKart, randomCustom, sanitizeCustom, OPTIONS, SWATCHES, SKINS } from './kart.js';
import { playHorn } from './horns.js';

const $ = (id) => document.getElementById(id);
let custom = null;
try { custom = sanitizeCustom(JSON.parse(localStorage.getItem('kr_custom') || 'null')); if (!localStorage.getItem('kr_custom')) custom = null; } catch (e) { custom = null; }

// ---------------- 3D preview ----------------
let R = null, scene, cam, stage = [], kart = null, running = false, spin = 0.6, dragging = false, lastX = 0, autoSpin = true;
function initPreview() {
  if (R) return;
  try {
    R = new THREE.WebGLRenderer({ canvas: $('pv'), antialias: true, alpha: true, preserveDrawingBuffer: true });
    R.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    R.outputColorSpace = THREE.SRGBColorSpace;
  } catch (e) { R = null; $('pv').classList.add('hidden'); return; }
  scene = new THREE.Scene();
  scene.add(new THREE.HemisphereLight('#ffffff', '#55506a', 1.9));
  const d = new THREE.DirectionalLight('#ffffff', 2.3); d.position.set(3, 6, 5); scene.add(d);
  const disc = new THREE.Mesh(new THREE.CylinderGeometry(3, 3, 0.15, 40), new THREE.MeshStandardMaterial({ color: '#3a2a66', roughness: 0.6 }));
  disc.position.y = -0.08; scene.add(disc);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(3, 0.06, 6, 50), new THREE.MeshBasicMaterial({ color: '#ffcf3f' }));
  ring.rotation.x = Math.PI / 2; scene.add(ring); stage = [disc, ring];
  cam = new THREE.PerspectiveCamera(32, 1, 0.1, 50);
  const cv = $('pv');
  cv.addEventListener('pointerdown', (e) => { dragging = true; autoSpin = false; lastX = e.clientX; cv.setPointerCapture(e.pointerId); });
  cv.addEventListener('pointermove', (e) => { if (dragging) { spin += (e.clientX - lastX) * 0.012; lastX = e.clientX; } });
  cv.addEventListener('pointerup', () => { dragging = false; });
  cv.addEventListener('pointercancel', () => { dragging = false; });
}
function setPreview(c) {
  if (!R) return;
  if (kart) scene.remove(kart.group);
  kart = buildKart(c); kart.group.children[1].visible = false;
  scene.add(kart.group);
}
function loop() {
  if (!running || !R) return;
  const cv = $('pv'), w = cv.clientWidth, h = cv.clientHeight;
  if (w && h && (cv.width !== Math.floor(w * R.getPixelRatio()) || cv.height !== Math.floor(h * R.getPixelRatio()))) {
    R.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix();
  }
  const dist = cam.aspect < 1 ? 9.5 : 7.2;
  cam.position.set(0, 2.6, dist); cam.lookAt(0, 0.8, 0);
  if (autoSpin) spin += 0.012;
  if (kart) kart.group.rotation.y = spin;
  R.render(scene, cam);
  requestAnimationFrame(loop);
}

// ---------------- UI ----------------
const FACE_ICONS = ['😊', '😎', '😤', '😜'];
const STICKER_ICONS = ['✖', '⭐', '🔥', '⚡', '🏳️', '❤️'];
const TRAIL_COLS = ['linear-gradient(90deg,#ffb02e,#ff5a1f)', 'linear-gradient(90deg,#46b3ff,#b5ecff)', 'linear-gradient(90deg,#7dff6b,#2cbf55)', 'linear-gradient(90deg,#ff62b0,#ffd1e8)', 'linear-gradient(90deg,red,orange,yellow,lime,cyan,blue,violet)'];
const TABS = {
  kart: [
    { key: 'body', label: 'Body', type: 'pills', opts: OPTIONS.body },
    { key: 'color', label: 'Main colour', type: 'swatch', opts: SWATCHES },
    { key: 'accent', label: 'Accent colour', type: 'swatch', opts: SWATCHES },
    { key: 'wheels', label: 'Wheels', type: 'pills', opts: OPTIONS.wheels },
    { key: 'number', label: 'Racing number', type: 'number' },
    { key: 'sticker', label: 'Sticker', type: 'pills', opts: OPTIONS.sticker, icons: STICKER_ICONS },
  ],
  driver: [
    { key: 'skin', label: 'Skin tone', type: 'swatch', opts: SKINS },
    { key: 'suit', label: 'Outfit', type: 'swatch', opts: SWATCHES },
    { key: 'hat', label: 'Headwear', type: 'pills', opts: OPTIONS.hat },
    { key: 'face', label: 'Face', type: 'pills', opts: OPTIONS.face, icons: FACE_ICONS },
  ],
  extras: [
    { key: 'trail', label: 'Boost trail', type: 'pills', opts: OPTIONS.trail, grads: TRAIL_COLS },
    { key: 'horn', label: 'Horn (tap to hear)', type: 'pills', opts: OPTIONS.horn, icons: ['📢', '🦆', '🚚', '🤡', '🎺'] },
  ],
};
let tab = 'kart';
function renderRows() {
  const box = $('crows'); box.innerHTML = '';
  for (const row of TABS[tab]) {
    const r = document.createElement('div'); r.className = 'crow';
    const l = document.createElement('div'); l.className = 'clabel'; l.textContent = row.label; r.append(l);
    const opts = document.createElement('div'); opts.className = 'copts';
    if (row.type === 'swatch') {
      row.opts.forEach(col => {
        const b = document.createElement('button'); b.className = 'sw' + (custom[row.key] === col ? ' on' : ''); b.style.background = col;
        b.onclick = () => change(row.key, col); opts.append(b);
      });
    } else if (row.type === 'pills') {
      row.opts.forEach((name, i) => {
        const b = document.createElement('button'); b.className = 'pill' + (custom[row.key] === i ? ' on' : '');
        if (row.icons) { const s = document.createElement('span'); s.className = 'pi'; s.textContent = row.icons[i]; b.append(s); }
        if (row.grads) { const s = document.createElement('span'); s.className = 'grad'; s.style.background = row.grads[i]; b.append(s); }
        b.append(document.createTextNode(name));
        b.onclick = () => { change(row.key, i); if (row.key === 'horn') horn(i); };
        opts.append(b);
      });
    } else if (row.type === 'number') {
      const mk = (t, d) => { const b = document.createElement('button'); b.className = 'pill num'; b.textContent = t; b.onclick = () => change('number', (custom.number + d + 100) % 100); return b; };
      const v = document.createElement('span'); v.className = 'numv'; v.textContent = String(custom.number).padStart(2, '0');
      opts.append(mk('−', -1), v, mk('+', 1));
      const rnd = document.createElement('button'); rnd.className = 'pill'; rnd.textContent = '🎲'; rnd.onclick = () => change('number', 1 + Math.floor(Math.random() * 99)); opts.append(rnd);
    }
    r.append(opts); box.append(r);
  }
}
let sendT = null;
function commit() {
  localStorage.setItem('kr_custom', JSON.stringify(custom));
  setPreview(custom);
  document.documentElement.style.setProperty('--kc', custom.color);
  clearTimeout(sendT); sendT = setTimeout(() => window.KR && window.KR.sendCustom(custom), 250);
}
function change(key, val) { custom[key] = val; commit(); renderRows(); }
let AC = null;
function horn(type) {
  try { if (!AC) AC = new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === 'suspended') AC.resume(); playHorn(AC, type, 0.1); } catch (e) { /* no audio */ }
}

$('ctabs').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  tab = b.dataset.tab; [...$('ctabs').children].forEach(x => x.classList.toggle('on', x === b)); renderRows();
});
$('crand').onclick = () => { const n = custom.number; custom = randomCustom(); custom.number = n; commit(); renderRows(); };
$('cdone').onclick = () => { window.KR && window.KR.sendCustom(custom); close(); };

function open() {
  if (!custom) { custom = randomCustom(window.KR && window.KR.assignedColor()); commit(); }
  initPreview(); setPreview(custom); renderRows();
  window.KR.show('custom');
  if (!running) { running = true; requestAnimationFrame(loop); }
}
function snapshot() {
  if (!R || !kart) return;
  try { const keep = kart.group.rotation.y; kart.group.rotation.y = 0.6; stage.forEach(m => m.visible = false); cam.position.set(0, 2.4, 7); cam.lookAt(0, 0.8, 0); R.render(scene, cam); stage.forEach(m => m.visible = true); localStorage.setItem('kr_kartimg', $('pv').toDataURL('image/png')); kart.group.rotation.y = keep; } catch (e) { /* ignore */ }
}
function close() { snapshot(); running = false; window.KR.closeCustom(); }

window.KartCustom = {
  open, close: () => { running = false; },
  get: () => custom,
  ensure(color) { if (!custom) { custom = randomCustom(color); localStorage.setItem('kr_custom', JSON.stringify(custom)); } return custom; },
  hasSaved: () => !!localStorage.getItem('kr_custom'),
  horn,
};
window.dispatchEvent(new Event('kartcustom-ready'));
