// Synthesised horn sounds (no audio files needed). Used by the big screen and the phone preview.
export function playHorn(ac, type, vol = 0.12) {
  if (!ac) return;
  const t0 = ac.currentTime;
  const tone = (f, start, dur, wave = 'square', f2 = null, v = vol) => {
    const o = ac.createOscillator(), g = ac.createGain();
    o.type = wave; o.frequency.setValueAtTime(f, t0 + start);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, t0 + start + dur);
    g.gain.setValueAtTime(0.0001, t0 + start); g.gain.exponentialRampToValueAtTime(v, t0 + start + 0.02);
    g.gain.setValueAtTime(v, t0 + start + dur - 0.05); g.gain.exponentialRampToValueAtTime(0.0001, t0 + start + dur);
    o.connect(g); g.connect(ac.destination); o.start(t0 + start); o.stop(t0 + start + dur + 0.02);
  };
  switch (type) {
    case 1: tone(620, 0, 0.16, 'sawtooth', 380); tone(600, 0.2, 0.2, 'sawtooth', 340); break;               // duck
    case 2: tone(110, 0, 0.7, 'sawtooth', null, vol * 1.2); tone(138, 0, 0.7, 'square', null, vol * 0.6); break; // truck
    case 3: tone(300, 0, 0.18, 'square', 520); tone(520, 0.22, 0.25, 'square', 260); break;                   // clown
    case 4: [523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.09, i === 3 ? 0.3 : 0.08, 'sawtooth', null, vol * 0.8)); break; // trumpet
    default: tone(440, 0, 0.14); tone(440, 0.2, 0.22); break;                                                  // beep beep
  }
}
