// Kart Rush 3D Championship — host / big screen: registration, draw, bracket, races, results.
import * as THREE from 'three';
import { Race, fmtTime } from './race.js';
import { TRACKS } from './tracks.js';
import { buildKart, randomCustom, sanitizeCustom } from './kart.js';
import { playHorn } from './horns.js';

const $ = (id) => document.getElementById(id);
const PALETTE = ['#ef3b4a', '#2f7ff5', '#2cbf55', '#ffd23f', '#9d5cf0', '#ff8a1c', '#ff62b0', '#1fd0e0', '#a6dc23', '#f4f4f4', '#8b5a2b', '#00a6a6', '#c2185b', '#5c6bc0', '#ffab91', '#607d8b'];
const BOT_NAMES = ['Bolt', 'Nitro', 'Pixel', 'Turbo Tan', 'Rusty', 'Comet', 'Zippy', 'Blaze', 'Dash', 'Rocket', 'Sparky', 'Gizmo', 'Flash', 'Jet', 'Vroom', 'Skid', 'Drift King', 'Turbo Tini', 'Mr Speedy', 'Kilat', 'Laju', 'Petir', 'Ombak', 'Angin', 'Bintang', 'Helang', 'Harimau', 'Buaya', 'Kancil', 'Rusa', 'Pelanduk', 'Merak'];
const HEAT_LAPS = 3, FINAL_LAPS = 5, LEAGUE_ROUNDS = 3, LEAGUE_POINTS = [10, 6, 3, 1];
const ord = (n) => n + (['th', 'st', 'nd', 'rd'][(n % 100 > 10 && n % 100 < 14) ? 0 : n % 10] || 'th');
const shuffle = (a) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

// ======================= state =======================
const S = {
  code: null,
  players: [],        // {id, name, color, kind, online, custom}
  stage: 'reg',       // reg | draw | hub | race | hres | rres | champ
  tour: null,         // {mode, rounds:[{name, kind, entrants, target, heats:[{ids, laps, track, results}]}], ri, hi, points:{}, leagueDone}
  ready: {},          // id -> true for the called heat
  lastTrack: null,
};
const P = (id) => S.players.find(p => p.id === id);
function save() {
  try {
    localStorage.setItem('kr3d_state', JSON.stringify({ code: S.code, players: S.players.map(p => ({ ...p, online: p.kind === 'bot' })), stage: S.stage === 'race' ? 'hub' : S.stage, tour: S.tour, lastTrack: S.lastTrack }));
  } catch (e) { /* storage full / private mode */ }
}
function restore(code) {
  try {
    const d = JSON.parse(localStorage.getItem('kr3d_state') || 'null');
    if (!d || d.code !== code) return false;
    S.players = d.players || []; S.tour = d.tour; S.stage = d.stage || 'reg'; S.lastTrack = d.lastTrack;
    if (S.stage === 'hres' || S.stage === 'rres' || S.stage === 'draw') S.stage = 'hub';
    return true;
  } catch (e) { return false; }
}

// ======================= networking =======================
let ws = null, wsReady = false;
const hostToken = sessionStorage.getItem('kr3d_token') || (Math.random().toString(36).slice(2) + Date.now().toString(36));
sessionStorage.setItem('kr3d_token', hostToken);
function connect() {
  ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`);
  ws.onopen = () => { wsReady = true; $('conn').textContent = 'connected'; ws.send(JSON.stringify({ t: 'host', code: sessionStorage.getItem('kr3d_code') || undefined, token: hostToken, origin: location.origin })); };
  ws.onclose = () => { wsReady = false; $('conn').textContent = 'disconnected — retrying…'; setTimeout(connect, 1500); };
  ws.onmessage = (e) => { let m; try { m = JSON.parse(e.data); } catch (err) { return; } onMsg(m); };
}
const send = (m) => { if (wsReady) ws.send(JSON.stringify(m)); };
const toPlayer = (id, msg) => send({ t: 'to', id, msg });

function onMsg(m) {
  switch (m.t) {
    case 'room': {
      const fresh = S.code !== m.code;
      S.code = m.code; sessionStorage.setItem('kr3d_code', m.code);
      $('code').textContent = m.code; $('joinurl').textContent = m.url.replace(/^https?:\/\//, '');
      drawQR(m.qr);
      if (fresh && !S.players.length) restore(m.code);
      for (const p of m.players || []) {
        const ex = P(p.id);
        if (ex) ex.online = p.online; else addPlayer(p.id, p.name, p.online);
      }
      send({ t: 'lock', v: S.stage !== 'reg' });
      show(S.stage === 'race' ? 'hub' : S.stage);
      break;
    }
    case 'join': addPlayer(m.id, m.name, true); break;
    case 'back': { const p = P(m.id); if (p) { p.online = true; p.name = m.name; } else addPlayer(m.id, m.name, true); if (race) race.setOnline(m.id, true); refresh(); break; }
    case 'drop': { const p = P(m.id); if (p) p.online = false; if (race) race.setOnline(m.id, false); refresh(); break; }
    case 'in': if (race) race.setInput(m.id, Math.max(-1, Math.min(1, +m.s || 0)), m.d ? 1 : 0); break;
    case 'use': if (race) race.queueUse(m.id); break;
    case 'ready': { S.ready[m.id] = true; refresh(); sfx('join'); break; }
    case 'custom': { const p = P(m.id); if (p && m.custom && typeof m.custom === 'object') { p.custom = sanitizeCustom(m.custom); p.color = p.custom.color; save(); refresh(); } break; }
    case 'horn': {
      const p = P(m.id); if (!p) break;
      if (race) { race.honk(m.id); break; }
      const now = performance.now(); if (p._hornAt && now - p._hornAt < 1200) break; p._hornAt = now;
      sfx('horn', p.custom ? p.custom.horn : 0); honkChip(m.id);
      break;
    }
  }
}
function addPlayer(id, name, online) {
  if (P(id)) return;
  const used = new Set(S.players.map(p => p.color));
  const color = PALETTE.find(c => !used.has(c)) || PALETTE[S.players.length % PALETTE.length];
  S.players.push({ id, name, color, kind: 'human', online, custom: null });
  sfx('join');
  save(); refresh();
}

// ======================= tournament logic =======================
function koTarget(n) { return [16, 8, 4].find(t => t <= Math.floor(n * 0.67)) || 4; }
function roundName(n, target) {
  if (n <= 4) return 'Grand Final';
  if (target === 4) return 'Semi-finals';
  if (target === 8) return 'Quarter-finals';
  return 'Round 1';
}
function plan(n) {
  if (n < 2) return [];
  if (n <= 4) return [{ name: 'Grand Final', heats: 1 }];
  if (n <= 7) return [...Array(LEAGUE_ROUNDS)].map((_, i) => ({ name: `League ${i + 1}`, heats: Math.ceil(n / 4) })).concat([{ name: 'Grand Final', heats: 1 }]);
  const out = [];
  while (n > 4) { const t = koTarget(n); out.push({ name: roundName(n, t), heats: Math.ceil(n / 4) }); n = t; }
  out.push({ name: 'Grand Final', heats: 1 });
  return out;
}
function splitHeats(ids) {
  const k = Math.ceil(ids.length / 4), heats = [...Array(k)].map(() => []);
  shuffle(ids).forEach((id, i) => heats[i % k].push(id));
  return heats;
}
function makeRound(kind, entrants, name) {
  if (kind === 'final') return { name: 'Grand Final', kind, entrants, target: 1, heats: [{ ids: shuffle(entrants), laps: FINAL_LAPS, track: null, results: null }] };
  const target = kind === 'ko' ? koTarget(entrants.length) : null;
  return { name: name || roundName(entrants.length, target), kind, entrants, target, heats: splitHeats(entrants).map(ids => ({ ids, laps: HEAT_LAPS, track: null, results: null })) };
}
function startChampionship() {
  const ids = S.players.map(p => p.id), n = ids.length;
  if (n < 2) return;
  const tour = { mode: n <= 4 ? 'final' : n <= 7 ? 'league' : 'ko', rounds: [], ri: 0, hi: 0, points: {}, leagueRound: 0 };
  if (tour.mode === 'final') tour.rounds.push(makeRound('final', ids));
  else if (tour.mode === 'league') { tour.leagueRound = 1; tour.rounds.push(makeRound('league', ids, 'League Round 1')); ids.forEach(id => tour.points[id] = 0); }
  else tour.rounds.push(makeRound('ko', ids));
  S.tour = tour; S.ready = {};
  send({ t: 'lock', v: true });
  save();
  runDraw();
}
const curRound = () => S.tour && S.tour.rounds[S.tour.ri];
const curHeat = () => { const r = curRound(); return r && r.heats[S.tour.hi]; };

function heatTags(round, heat) {
  // what each place in a finished heat means (before the whole round is done)
  const k = round.heats.length, res = heat.results || [];
  return res.map((r) => {
    if (round.kind === 'final') return { cls: r.place === 1 ? 'in' : 'out', txt: r.place === 1 ? 'CHAMPION' : ord(r.place) };
    if (round.kind === 'league') return { cls: 'in', txt: `+${LEAGUE_POINTS[r.place - 1] || 0} pts` };
    if (round.target >= 2 * k) {
      if (r.place <= 2) return { cls: 'in', txt: 'THROUGH' };
      return round.target === 2 * k ? { cls: 'out', txt: 'OUT' } : { cls: 'maybe', txt: 'FASTEST-LOSER CHANCE' };
    }
    if (r.place === 1) return { cls: 'in', txt: 'THROUGH' };
    return r.place === 2 ? { cls: 'maybe', txt: 'FASTEST RUNNER-UP CHANCE' } : { cls: 'out', txt: 'OUT' };
  });
}
function rankKey(a, b) {
  if (a.finished !== b.finished) return a.finished ? -1 : 1;
  if (a.finished) return a.time - b.time;
  return b.progress - a.progress;
}
function computeAdvancers(round) {
  const tiers = [];
  for (const h of round.heats) for (const r of h.results) { (tiers[r.place - 1] = tiers[r.place - 1] || []).push(r); }
  const out = [], lucky = new Set();
  for (let t = 0; t < tiers.length && out.length < round.target; t++) {
    const tier = tiers[t].slice().sort(rankKey);
    for (const r of tier) {
      if (out.length >= round.target) break;
      out.push(r.id);
      if (t >= 2) lucky.add(r.id);
      else if (t === 1 && round.target < 2 * round.heats.length) lucky.add(r.id); // fastest runners-up when spots are short
    }
  }
  return { ids: out, lucky };
}
function leagueStandings() {
  const t = S.tour, ids = Object.keys(t.points).map(k => isNaN(+k) ? k : +k);
  const stats = {};
  for (const id of ids) stats[id] = { id, pts: t.points[id] || 0, places: 0, races: 0 };
  for (const rd of t.rounds) if (rd.kind === 'league') for (const h of rd.heats) for (const r of (h.results || [])) { if (stats[r.id]) { stats[r.id].places += r.place; stats[r.id].races++; } }
  return Object.values(stats).sort((a, b) => b.pts - a.pts || (a.places / (a.races || 1)) - (b.places / (b.races || 1)));
}
function onHeatDone(results) {
  const t = S.tour, round = curRound(), heat = curHeat();
  heat.results = results.map(r => ({ id: r.id, place: r.place, finished: r.finished, time: r.time, progress: r.progress }));
  if (round.kind === 'league') for (const r of heat.results) t.points[r.id] = (t.points[r.id] || 0) + (LEAGUE_POINTS[r.place - 1] || 0);
  S.ready = {};
  save();
  showHeatResult();
}
function afterHeatResult() {
  const t = S.tour, round = curRound();
  if (round.kind === 'final') { S.stage = 'champ'; save(); show('champ'); return; }
  if (t.hi < round.heats.length - 1) { t.hi++; save(); show('hub'); return; }
  // round complete
  if (round.kind === 'league') {
    if (t.leagueRound < LEAGUE_ROUNDS) {
      t.leagueRound++; t.rounds.push(makeRound('league', round.entrants, `League Round ${t.leagueRound}`)); t.ri++; t.hi = 0;
      showRoundResult(null); return;
    }
    const top = leagueStandings().slice(0, 4).map(s => s.id);
    round.advancers = top;
    t.rounds.push(makeRound('final', top)); t.ri++; t.hi = 0;
    showRoundResult({ ids: top, lucky: new Set() }, true); return;
  }
  const adv = computeAdvancers(round);
  round.advancers = adv.ids; round.lucky = [...adv.lucky];
  t.rounds.push(adv.ids.length <= 4 ? makeRound('final', adv.ids) : makeRound('ko', adv.ids)); t.ri++; t.hi = 0;
  showRoundResult(adv);
}
function eliminatedIn(id) {
  if (!S.tour) return null;
  for (let i = 0; i < S.tour.ri; i++) {
    const rd = S.tour.rounds[i];
    if (rd.advancers && rd.entrants.includes(id) && !rd.advancers.includes(id)) return rd.name;
  }
  return null;
}

// ======================= screens =======================
const SCREENS = ['reg', 'draw', 'hub', 'hres', 'rres', 'champ'];
function show(name) {
  S.stage = name;
  for (const s of SCREENS) $(s).classList.toggle('hidden', s !== name);
  const racing = name === 'race';
  $('gl').classList.toggle('hidden', !racing); $('hud').classList.toggle('hidden', !racing);
  $('confetti').classList.toggle('hidden', name !== 'champ');
  refresh();
}
function refresh() {
  if (S.stage === 'reg') renderReg();
  else if (S.stage === 'hub') renderHub();
  else if (S.stage === 'champ') renderChamp();
  notifyPlayers();
}

// ---------- kart thumbnails (rendered once per customisation) ----------
let thumbR = null, thumbScene = null, thumbCam = null;
const thumbCache = new Map();
function kartThumb(custom) {
  const key = JSON.stringify(custom);
  if (thumbCache.has(key)) return thumbCache.get(key);
  try {
    if (!thumbR) {
      const c = document.createElement('canvas'); c.width = 240; c.height = 160;
      thumbR = new THREE.WebGLRenderer({ canvas: c, alpha: true, antialias: true, preserveDrawingBuffer: true });
      thumbR.setSize(240, 160, false); thumbR.outputColorSpace = THREE.SRGBColorSpace;
      thumbScene = new THREE.Scene();
      thumbScene.add(new THREE.HemisphereLight('#ffffff', '#55506a', 1.9));
      const d = new THREE.DirectionalLight('#ffffff', 2.2); d.position.set(3, 6, 5); thumbScene.add(d);
      thumbCam = new THREE.PerspectiveCamera(30, 1.5, 0.1, 50); thumbCam.position.set(4.6, 3.1, 5.6); thumbCam.lookAt(0, 0.85, 0.1);
    }
    const k = buildKart(custom); k.group.children[1].visible = false;
    thumbScene.add(k.group); thumbR.render(thumbScene, thumbCam);
    const url = thumbR.domElement.toDataURL('image/png');
    thumbScene.remove(k.group);
    thumbCache.set(key, url); return url;
  } catch (e) { return null; }
}
function avatar(p, cls) {
  const url = p.custom ? kartThumb(p.custom) : null;
  if (url) { const i = document.createElement('img'); i.className = cls; i.src = url; i.alt = ''; return i; }
  const dot = document.createElement('span'); dot.className = 'dot'; dot.style.background = p.color; return dot;
}
function honkChip(id) {
  document.querySelectorAll(`[data-pid="${CSS.escape(String(id))}"]`).forEach(el => { el.classList.remove('honk'); void el.offsetWidth; el.classList.add('honk'); });
}
const seenChips = new Set();
function chip(p, extra, animate) {
  const d = document.createElement('div'); d.className = 'chip' + (p.online || p.kind === 'bot' ? '' : ' off');
  if (!animate) d.style.animation = 'none';
  d.dataset.pid = p.id;
  const nm = document.createElement('span'); nm.className = 'nm'; nm.textContent = p.name;
  d.append(avatar(p, 'thumb'), nm);
  if (extra) { const t = document.createElement('span'); t.className = 'tag'; t.textContent = extra; d.append(t); }
  return d;
}
function renderReg() {
  const list = $('plist'); list.innerHTML = '';
  if (!S.players.length) list.innerHTML = '<div class="empty">Waiting for racers to scan in…</div>';
  for (const p of S.players) {
    const c = chip(p, p.kind === 'bot' ? 'bot' : (p.online ? '' : 'away'), !seenChips.has(p.id)); seenChips.add(p.id);
    const x = document.createElement('button'); x.className = 'x'; x.textContent = '✕'; x.title = 'Remove';
    x.onclick = () => { S.players = S.players.filter(q => q !== p); if (p.kind === 'human') send({ t: 'kick', id: p.id }); save(); refresh(); };
    c.append(x); list.append(c);
  }
  const n = S.players.length;
  $('pcount').textContent = `${n} / 32`;
  $('startchamp').disabled = n < 2;
  $('addbots').disabled = n >= 32;
  const pl = plan(n);
  if (!pl.length) { $('format').innerHTML = 'Need at least <b>2</b> racers (8+ for a full knockout).'; return; }
  const races = pl.reduce((a, r) => a + r.heats, 0);
  const mins = Math.round((races - 1) * 4 + 6);
  const mode = n <= 4 ? 'Straight to the Grand Final' : n <= 7 ? 'Points league (everyone races 3 times), top 4 to the final' : 'Knockout — top 2 in each heat go through';
  $('format').innerHTML = `<b>${n} racers:</b> ${mode}<br>${pl.map(r => `${r.name}${r.heats > 1 ? ` (${r.heats} heats)` : ''}`).join(' → ')}<br><span style="opacity:.7">${races} races · about ${mins} minutes</span>`;
}

// ---------- draw animation ----------
let drawTimer = null;
function runDraw() {
  show('draw');
  const round = curRound();
  $('drawtitle').textContent = `THE DRAW — ${round.name.toUpperCase()}`;
  $('drawsub').textContent = round.kind === 'final' ? 'Grid order for the Grand Final' : `${round.entrants.length} racers into ${round.heats.length} heats`;
  const box = $('drawheats'); box.innerHTML = '';
  const cards = round.heats.map((h, i) => {
    const c = document.createElement('div'); c.className = 'heat';
    c.innerHTML = `<h3>${round.kind === 'final' ? 'Grand Final' : 'Heat ' + (i + 1)}<span class="st">${h.laps} laps</span></h3>`;
    box.append(c); return c;
  });
  const seq = []; round.heats.forEach((h, i) => h.ids.forEach((id, k) => seq.push([k, i, id])));
  seq.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  let k = 0; $('drawgo').disabled = true;
  clearInterval(drawTimer);
  drawTimer = setInterval(() => {
    if (k >= seq.length) { clearInterval(drawTimer); $('drawgo').disabled = false; sfx('finish'); return; }
    const [, hi, id] = seq[k++]; const p = P(id);
    const row = document.createElement('div'); row.className = 'hp flyin';
    row.innerHTML = `<span class="dot"></span><span class="nm"></span>`;
    row.querySelector('.dot').style.background = p.color; row.querySelector('.nm').textContent = p.name;
    cards[hi].append(row); sfx('tick');
  }, Math.max(90, Math.min(260, 4000 / seq.length)));
}

// ---------- hub ----------
let autoStartAt = 0;
function renderHub() {
  const t = S.tour; if (!t) return;
  const round = curRound(), heat = curHeat();
  $('hubtitle').textContent = round.name.toUpperCase() + (round.kind !== 'final' ? `  ·  HEAT ${t.hi + 1} OF ${round.heats.length}` : '');
  // stage pills
  const st = $('stages'); st.innerHTML = '';
  const names = t.rounds.map(r => r.name);
  const future = plan(round.entrants.length).slice(1).map(r => r.name);
  if (round.kind === 'league') future.splice(0, future.length, ...[...Array(LEAGUE_ROUNDS - t.leagueRound)].map((_, i) => `League Round ${t.leagueRound + i + 1}`), 'Grand Final');
  [...names, ...future].forEach((n, i) => {
    const s = document.createElement('span'); s.className = 'stage' + (i === t.ri ? ' cur' : i < t.ri ? ' past' : ''); s.textContent = n; st.append(s);
  });
  // heat cards
  const box = $('hubheats'); box.innerHTML = '';
  round.heats.forEach((h, i) => {
    const c = document.createElement('div');
    c.className = 'heat' + (i === t.hi ? ' next' : '') + (h.results ? ' done' : '');
    const status = h.results ? 'done' : i === t.hi ? 'next' : 'waiting';
    c.innerHTML = `<h3>${round.kind === 'final' ? 'Grand Final' : 'Heat ' + (i + 1)}<span class="st">${status}</span></h3>`;
    const tags = h.results ? heatTags(round, h) : null;
    const rows = h.results ? h.results.map((r, k) => ({ id: r.id, place: r.place, tag: tags[k] })) : h.ids.map(id => ({ id }));
    for (const r of rows) {
      const p = P(r.id); if (!p) continue;
      const d = document.createElement('div'); d.className = 'hp';
      d.innerHTML = `${r.place ? `<span class="pl">${ord(r.place)}</span>` : ''}<span class="dot"></span><span class="nm"></span>${r.tag && r.tag.cls === 'in' ? `<span class="ok">${r.tag.txt === 'THROUGH' ? '✓' : r.tag.txt}</span>` : ''}`;
      d.querySelector('.dot').style.background = p.color; d.querySelector('.nm').textContent = p.name;
      c.append(d);
    }
    box.append(c);
  });
  // league standings
  const lb = $('leaguebox'); lb.innerHTML = '';
  if (round.kind === 'league') {
    const c = document.createElement('div'); c.className = 'card'; c.style.marginTop = '16px';
    c.innerHTML = '<h3 style="margin:0">League table — top 4 reach the Grand Final</h3>';
    const tb = document.createElement('table'); tb.className = 'std';
    leagueStandings().forEach((s, i) => {
      const p = P(s.id); if (!p) return;
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${i + 1}</td><td><span class="dot"></span> <span class="nm"></span></td><td class="r">${s.pts} pts</td>`;
      tr.querySelector('.dot').style.background = p.color; tr.querySelector('.nm').textContent = p.name;
      if (i === 3) tr.style.borderBottom = '3px solid var(--gold)';
      tb.append(tr);
    });
    c.append(tb); lb.append(c);
  }
  // next up panel
  const nu = $('nextup');
  const humans = heat.ids.filter(id => P(id) && P(id).kind === 'human');
  const allReady = humans.every(id => S.ready[id] || !P(id).online);
  nu.innerHTML = `<h2>Next up</h2><div class="hn">${round.kind === 'final' ? 'GRAND FINAL' : 'HEAT ' + (t.hi + 1)}</div>
    <div class="info">${heat.laps} laps · track picked at random · players: grab your phones!</div>`;
  for (const id of heat.ids) {
    const p = P(id); if (!p) continue;
    const d = document.createElement('div'); d.className = 'np';
    const rd = p.kind === 'bot' ? 'BOT' : !p.online ? 'OFFLINE' : S.ready[id] ? 'READY' : 'waiting…';
    d.dataset.pid = p.id;
    d.innerHTML = `<span class="nm"></span><span class="rd ${S.ready[id] || p.kind === 'bot' ? 'yes' : ''}">${rd}</span>`;
    d.querySelector('.nm').textContent = p.name; d.prepend(avatar(p, 'thumb big'));
    nu.append(d);
  }
  const btn = document.createElement('button'); btn.className = 'go btn'; btn.style.width = '100%'; btn.style.marginTop = '10px';
  btn.textContent = round.kind === 'final' ? 'START GRAND FINAL' : 'START HEAT'; btn.onclick = () => startHeat();
  nu.append(btn);
  const au = document.createElement('div'); au.className = 'auto'; au.id = 'autostart'; nu.append(au);
  const hint = document.createElement('div'); hint.className = 'hint'; hint.textContent = 'Starts automatically when everyone taps READY. Offline players drive on autopilot.'; nu.append(hint);
  if (allReady && humans.length && !autoStartAt) autoStartAt = performance.now() + 4000;
  if (!allReady) autoStartAt = 0;
}

// ---------- race ----------
let renderer = null, race = null, raceView = { W: 0, H: 0 };
function ensureRenderer() {
  if (renderer) return;
  renderer = new THREE.WebGLRenderer({ canvas: $('gl'), antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  resize();
}
function resize() {
  const W = innerWidth, H = innerHeight; raceView = { W, H };
  if (renderer) renderer.setSize(W, H, false);
  const hud = $('hud'), dpr = Math.min(window.devicePixelRatio || 1, 2);
  hud.width = W * dpr; hud.height = H * dpr;
  const cf = $('confetti'); cf.width = W; cf.height = H;
}
addEventListener('resize', resize);

function pickTrack() {
  const pool = TRACKS.length > 1 ? TRACKS.filter(t => t.id !== S.lastTrack) : TRACKS;
  const t = pool[Math.floor(Math.random() * pool.length)];
  S.lastTrack = t.id; return t.id;
}
function startHeat() {
  if (race || S.stage !== 'hub') return;
  autoStartAt = 0;
  ensureRenderer(); audioUnlock();
  const round = curRound(), heat = curHeat();
  heat.track = pickTrack();
  const entrants = heat.ids.map(id => P(id)).filter(Boolean).map(p => ({ id: p.id, name: p.name, color: p.color, kind: p.kind, online: p.kind === 'bot' || p.online, custom: p.custom }));
  race = new Race({
    renderer, hud: $('hud'), trackId: heat.track, entrants, laps: heat.laps,
    title: round.kind === 'final' ? 'GRAND FINAL' : `${round.name} · Heat ${S.tour.hi + 1}`,
    sfx, onEvent: onRaceEvent,
  });
  show('race');
  save();
}
function onRaceEvent(type, d) {
  if (type === 'fx') toPlayer(d.id, { t: 'fx', k: d.k });
  else if (type === 'done') {
    setTimeout(() => {
      const results = d.results;
      race.destroy(); race = null;
      onHeatDone(results);
    }, 3500);
  }
}
let statusT = 0;
function sendRaceStatus() {
  if (!race) return;
  for (const r of race.racers) {
    const p = P(r.id); if (!p || p.kind !== 'human' || !p.online) continue;
    const st = race.statusFor(r.id); st.t = 'st';
    const key = JSON.stringify(st);
    if (key !== r.lastStatus) { r.lastStatus = key; toPlayer(r.id, st); }
  }
}

// ---------- results ----------
function resultRow(r, tag) {
  const p = P(r.id) || { name: '?', color: '#999' };
  const tr = document.createElement('tr');
  tr.innerHTML = `<td>${ord(r.place)}</td><td><span class="dot"></span> <span class="nm"></span>${p.kind === 'bot' ? ' <span style="opacity:.5">(bot)</span>' : ''}</td><td class="r">${r.finished ? fmtTime(r.time) : 'DNF'}</td><td class="r">${tag ? `<span class="tag2 ${tag.cls}">${tag.txt}</span>` : ''}</td>`;
  tr.querySelector('.dot').style.background = p.color; tr.querySelector('.nm').textContent = p.name;
  return tr;
}
function showHeatResult() {
  const round = curRound(), heat = curHeat();
  if (round.kind === 'final') { S.stage = 'champ'; save(); show('champ'); return; }
  show('hres');
  $('hrestitle').textContent = `${round.name.toUpperCase()} · HEAT ${S.tour.hi + 1}`;
  const tb = $('hrestable'); tb.innerHTML = '';
  const tags = heatTags(round, heat);
  heat.results.forEach((r, i) => tb.append(resultRow(r, tags[i])));
  $('hresnote').textContent = round.kind === 'league' ? 'Points: 1st 10 · 2nd 6 · 3rd 3 · 4th 1' :
    (round.target > 2 * round.heats.length ? `Top 2 go through. ${round.target - 2 * round.heats.length} more spots go to the fastest losers across all heats.` :
      round.target < 2 * round.heats.length ? 'Heat winners go through, plus the fastest runners-up.' : 'Top 2 go through to the next round.');
  sfx('finish');
}
function showRoundResult(adv, toFinal) {
  save();
  show('rres');
  const prev = S.tour.rounds[S.tour.ri - 1], next = curRound();
  $('rrestitle').textContent = `${prev.name.toUpperCase()} COMPLETE`;
  const box = $('rresadv'); box.innerHTML = '';
  if (!adv) {
    $('rressub').textContent = `On to ${next.name}! New shuffle — everyone races again.`;
    leagueStandings().forEach((s, i) => { const p = P(s.id); if (p) box.append(chip(p, `${s.pts} pts`)); });
  } else {
    $('rressub').textContent = toFinal ? 'The top 4 of the league go to the GRAND FINAL!' : `Through to the ${next.name}:`;
    adv.ids.forEach((id, i) => {
      const p = P(id); if (!p) return;
      const c = chip(p, adv.lucky.has(id) ? 'fastest loser' : '', true);
      c.style.animationDelay = (i * 0.08) + 's'; box.append(c);
    });
  }
  sfx('fanfare');
}

// ---------- champion ----------
let confettiOn = false;
function renderChamp() {
  const fin = S.tour && S.tour.rounds[S.tour.ri];
  if (!fin || !fin.heats[0].results) return;
  const res = fin.heats[0].results;
  const pod = $('podium'); pod.innerHTML = '';
  for (const k of [1, 0, 2]) {
    const r = res[k]; if (!r) continue; const p = P(r.id); if (!p) continue;
    const d = document.createElement('div'); d.className = 'pod p' + (k + 1);
    d.innerHTML = `${k === 0 ? '<div class="crown">👑</div>' : ''}<div class="nm"></div><div class="kslot"></div><div class="block">${k + 1}</div>`;
    d.querySelector('.nm').textContent = p.name; d.querySelector('.kslot').append(avatar(p, 'podthumb'));
    pod.append(d);
  }
  const tb = $('champtable'); tb.innerHTML = '';
  res.forEach(r => tb.append(resultRow(r, null)));
  if (!confettiOn) { confettiOn = true; startConfetti(); sfx('fanfare'); }
}
function startConfetti() {
  const c = $('confetti'), g = c.getContext('2d');
  const bits = [...Array(220)].map(() => ({ x: Math.random() * c.width, y: -Math.random() * c.height, vy: 60 + Math.random() * 120, vx: (Math.random() - 0.5) * 60, r: Math.random() * 6, s: 6 + Math.random() * 8, col: PALETTE[Math.floor(Math.random() * 10)] }));
  let last = performance.now();
  const tick = (now) => {
    if (S.stage !== 'champ') { confettiOn = false; g.clearRect(0, 0, c.width, c.height); return; }
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    g.clearRect(0, 0, c.width, c.height);
    for (const b of bits) {
      b.y += b.vy * dt; b.x += b.vx * dt + Math.sin(now / 400 + b.r) * 0.6; b.r += dt * 4;
      if (b.y > c.height + 20) { b.y = -20; b.x = Math.random() * c.width; }
      g.save(); g.translate(b.x, b.y); g.rotate(b.r); g.fillStyle = b.col; g.fillRect(-b.s / 2, -b.s / 4, b.s, b.s / 2); g.restore();
    }
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

// ---------- phone notifications ----------
function playerState(p) {
  const t = S.tour;
  if (!t || S.stage === 'reg') return { st: 'registered', title: "You're registered!", msg: 'Wait for the host to start the championship.' };
  const round = curRound();
  if (S.stage === 'champ') {
    const res = round.heats[0].results || [];
    const me = res.find(r => r.id === p.id);
    if (me && me.place === 1) return { st: 'champion', title: '🏆 CHAMPION!', msg: 'You won the Kart Rush Championship!' };
    if (me) return { st: 'done', title: `${ord(me.place)} in the Grand Final`, msg: 'What a race! Well driven.' };
    return { st: 'done', title: 'Championship over', msg: 'Thanks for racing! See the podium on the big screen.' };
  }
  const out = eliminatedIn(p.id);
  if (out && !round.entrants.includes(p.id)) return { st: 'out', title: 'Knocked out', msg: `You went out in the ${out}. Thanks for racing — cheer on the others!` };
  if (!round.entrants.includes(p.id)) return { st: 'out', title: 'Not in this round', msg: 'Watch the big screen!' };
  const hIdx = round.heats.findIndex(h => h.ids.includes(p.id));
  const heat = round.heats[hIdx];
  const label = round.kind === 'final' ? 'the GRAND FINAL' : `Heat ${hIdx + 1}`;
  if (S.stage === 'race' && hIdx === t.hi) return { st: 'racing', title: 'Racing!', msg: '' };
  if (S.stage === 'rres') return { st: 'through', title: round.kind === 'final' ? "You're in the GRAND FINAL! 🏁" : `Through to the ${round.name}!`, msg: `You're in ${label}.` };
  if (heat.results) {
    const me = heat.results.find(r => r.id === p.id);
    const tag = heatTags(round, heat)[heat.results.indexOf(me)];
    const extra = tag.cls === 'in' ? (round.kind === 'league' ? `You earned ${tag.txt}.` : "You're through! 🎉") : tag.cls === 'maybe' ? 'You might still go through as a fastest loser — fingers crossed!' : 'Unlucky — you are out.';
    return { st: 'heatdone', title: `You finished ${ord(me.place)}`, msg: extra };
  }
  if (hIdx === t.hi) return { st: 'called', title: "YOU'RE UP!", msg: `${label} is next. Get ready and tap READY.`, ready: !!S.ready[p.id] };
  const before = hIdx - t.hi;
  return { st: 'waiting', title: `You're in ${label}`, msg: before === 1 ? "You're on after the next race — stay close!" : `${before} races before yours. Watch the big screen!` };
}
function notifyPlayers() {
  for (const p of S.players) {
    if (p.kind !== 'human' || !p.online) continue;
    const s = playerState(p); s.t = 'tour'; s.color = p.color; s.name = p.name;
    const key = JSON.stringify(s);
    if (key !== p._lastTour) { p._lastTour = key; toPlayer(p.id, s); if (s.st === 'called' && !s.ready) toPlayer(p.id, { t: 'fx', k: 'called' }); }
  }
}

// ======================= buttons & keys =======================
$('addbots').onclick = () => {
  for (let k = 0; k < 4 && S.players.length < 32; k++) {
    const used = new Set(S.players.map(p => p.name));
    const name = BOT_NAMES.find(n => !used.has(n)) || 'Bot ' + Math.floor(Math.random() * 999);
    const usedC = new Set(S.players.map(p => p.color));
    const bc = PALETTE.find(c => !usedC.has(c)) || PALETTE[S.players.length % PALETTE.length];
    const custom = randomCustom(); S.players.push({ id: 'b' + Math.random().toString(36).slice(2, 8), name, color: custom.color, kind: 'bot', online: true, custom });
  }
  save(); refresh();
};
$('clearbots').onclick = () => { S.players = S.players.filter(p => p.kind !== 'bot'); save(); refresh(); };
$('startchamp').onclick = () => { audioUnlock(); startChampionship(); };
$('drawgo').onclick = () => { S.tour.hi = 0; save(); show('hub'); };
$('hresgo').onclick = () => afterHeatResult();
$('rresgo').onclick = () => runDraw();
$('newchamp').onclick = () => { S.tour = null; S.ready = {}; send({ t: 'lock', v: false }); save(); show('reg'); };
$('resetall').onclick = () => {
  if (!confirm('Remove all racers and start over?')) return;
  for (const p of S.players) if (p.kind === 'human') send({ t: 'kick', id: p.id });
  S.players = []; S.tour = null; S.ready = {}; send({ t: 'lock', v: false }); save(); show('reg');
};
let fastForward = false;
addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    if (S.stage === 'reg' && !$('startchamp').disabled) $('startchamp').click();
    else if (S.stage === 'draw' && !$('drawgo').disabled) $('drawgo').click();
    else if (S.stage === 'hub') startHeat();
    else if (S.stage === 'hres') $('hresgo').click();
    else if (S.stage === 'rres') $('rresgo').click();
  }
  if (e.key === 'f' || e.key === 'F') fastForward = true;
});
addEventListener('keyup', (e) => { if (e.key === 'f' || e.key === 'F') fastForward = false; });

function drawQR(rows) {
  const c = $('qr'), g = c.getContext('2d'), n = rows.length, cell = Math.floor(c.width / (n + 4)), off = Math.floor((c.width - cell * n) / 2);
  g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.fillStyle = '#1b1430';
  for (let r = 0; r < n; r++) for (let k = 0; k < n; k++) if (rows[r][k] === '1') g.fillRect(off + k * cell, off + r * cell, cell, cell);
}

// ======================= audio =======================
let AC = null;
function audioUnlock() { if (!AC) { try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { /* none */ } } if (AC && AC.state === 'suspended') AC.resume(); }
document.addEventListener('pointerdown', audioUnlock);
function tone(f, dur, type = 'square', vol = 0.08, slide = 0, delay = 0) {
  if (!AC) return;
  const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime + delay;
  o.type = type; o.frequency.setValueAtTime(f, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f + slide), t + dur);
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + dur + 0.02);
}
function noise(dur, vol = 0.2) {
  if (!AC) return;
  const b = AC.createBuffer(1, AC.sampleRate * dur, AC.sampleRate), d = b.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length) ** 2;
  const s = AC.createBufferSource(), g = AC.createGain(); s.buffer = b; g.gain.value = vol; s.connect(g); g.connect(AC.destination); s.start();
}
const lastS = {};
function sfx(k, arg) {
  if (k === 'horn') { playHorn(AC, arg || 0); return; }
  const now = performance.now(); if (lastS[k] && now - lastS[k] < 70) return; lastS[k] = now;
  switch (k) {
    case 'beep': tone(440, 0.25, 'square', 0.1); break;
    case 'go': tone(880, 0.6, 'square', 0.12); break;
    case 'box': tone(660, 0.08, 'triangle', 0.06); tone(990, 0.1, 'triangle', 0.06, 0, 0.07); break;
    case 'boost': tone(200, 0.4, 'sawtooth', 0.05, 500); break;
    case 'hit': tone(300, 0.35, 'sawtooth', 0.07, -250); break;
    case 'zap': tone(1200, 0.25, 'square', 0.04, -900); break;
    case 'bounce': tone(700, 0.06, 'square', 0.03); break;
    case 'drop': tone(160, 0.15, 'sine', 0.1); break;
    case 'shield': tone(520, 0.3, 'sine', 0.08, 300); break;
    case 'shieldbreak': tone(900, 0.2, 'triangle', 0.08, -600); break;
    case 'throw': tone(300, 0.3, 'triangle', 0.06, 300); break;
    case 'splat': noise(0.35, 0.25); tone(120, 0.3, 'sine', 0.12, -60); break;
    case 'fuse': tone(1500, 0.1, 'square', 0.03); break;
    case 'pass': tone(500, 0.12, 'square', 0.07); tone(750, 0.12, 'square', 0.07, 0, 0.1); break;
    case 'boom': noise(0.8, 0.45); tone(80, 0.6, 'sine', 0.2, -40); break;
    case 'thunder': noise(1.0, 0.35); break;
    case 'finallap': [660, 880, 1100].forEach((f, i) => tone(f, 0.15, 'square', 0.06, 0, i * 0.12)); break;
    case 'join': tone(523, 0.1, 'triangle', 0.07); tone(784, 0.15, 'triangle', 0.07, 0, 0.09); break;
    case 'tick': tone(900 + Math.random() * 300, 0.05, 'triangle', 0.05); break;
    case 'finish': [523, 659, 784].forEach((f, i) => tone(f, 0.18, 'triangle', 0.08, 0, i * 0.11)); break;
    case 'fanfare': [523, 659, 784, 1047, 784, 1047].forEach((f, i) => tone(f, 0.22, 'square', 0.06, 0, i * 0.14)); break;
  }
}

// ======================= main loop =======================
let last = performance.now();
function frame(now) {
  const dt = Math.min(0.1, (now - last) / 1000); last = now;
  if (race) {
    const mult = fastForward ? 8 : 1;
    const steps = Math.ceil(dt * mult / (1 / 120));
    for (let i = 0; i < steps; i++) race.step(dt * mult / steps);
    race.render(raceView.W, raceView.H, dt);
    statusT -= dt; if (statusT <= 0) { statusT = 0.12; sendRaceStatus(); }
  }
  if (autoStartAt && S.stage === 'hub') {
    const left = Math.ceil((autoStartAt - performance.now()) / 1000);
    const el = $('autostart'); if (el) el.textContent = `Everyone's ready — starting in ${Math.max(0, left)}…`;
    if (left <= 0) startHeat();
  }
  requestAnimationFrame(frame);
}
// keep an online (free) server awake while the big screen is open
setInterval(() => { fetch('/health', { cache: 'no-store' }).catch(() => {}); }, 4 * 60 * 1000);

resize();
show('reg');
connect();
requestAnimationFrame(frame);
window.__kr3d = { S, startHeat, get race() { return race; }, set ff(v) { fastForward = v; }, computeAdvancers, plan };
