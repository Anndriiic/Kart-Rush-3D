// Low-poly kart + driver built from simple shapes, fully driven by a "custom" config
// that players edit on their phones. Shared by the phone preview, the big screen and the race.
import * as THREE from 'three';

// ---------------- options (shared with the phone customiser) ----------------
export const SWATCHES = ['#ef3b4a', '#ff8a1c', '#ffd23f', '#a6dc23', '#2cbf55', '#1fd0e0', '#2f7ff5', '#5c6bc0', '#9d5cf0', '#ff62b0', '#f4f4f4', '#2b2b33'];
export const SKINS = ['#f6d3b3', '#e8b98f', '#d19a6a', '#b07a4f', '#8a5a36', '#5e3b22'];
export const OPTIONS = {
  body:    ['Classic', 'Rocket', 'Buggy'],
  wheels:  ['Standard', 'Sporty', 'Gold'],
  sticker: ['None', 'Star', 'Flame', 'Bolt', 'Flag', 'Heart'],
  hat:     ['Helmet', 'Cap', 'Songkok', 'Tudong', 'Headband', 'Crown'],
  face:    ['Happy', 'Cool', 'Determined', 'Cheeky'],
  trail:   ['Fire', 'Blue', 'Green', 'Pink', 'Rainbow'],
  horn:    ['Beep', 'Duck', 'Truck', 'Clown', 'Trumpet'],
};
export const TRAILS = {
  0: ['#ffb02e', '#ff5a1f'], 1: ['#46b3ff', '#b5ecff'], 2: ['#7dff6b', '#2cbf55'], 3: ['#ff62b0', '#ffd1e8'], 4: null, // rainbow
};
export const DEFAULT_CUSTOM = { body: 0, color: '#ef3b4a', accent: '#f4f4f4', wheels: 0, number: 7, sticker: 0, skin: '#d19a6a', suit: '#2f7ff5', hat: 0, face: 0, trail: 0, horn: 0 };
export function randomCustom(color) {
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  const main = color || pick(SWATCHES);
  let accent = pick(SWATCHES); if (accent === main) accent = '#f4f4f4';
  return {
    body: Math.floor(Math.random() * 3), color: main, accent, wheels: Math.floor(Math.random() * 3), number: 1 + Math.floor(Math.random() * 99),
    sticker: Math.floor(Math.random() * OPTIONS.sticker.length), skin: pick(SKINS), suit: pick(SWATCHES), hat: Math.floor(Math.random() * OPTIONS.hat.length),
    face: Math.floor(Math.random() * 4), trail: Math.floor(Math.random() * 5), horn: Math.floor(Math.random() * 5),
  };
}
export function sanitizeCustom(c) {
  const d = { ...DEFAULT_CUSTOM };
  if (!c || typeof c !== 'object') return d;
  const hex = (v, list, def) => (typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v) ? v : def);
  const int = (v, max, def) => (Number.isInteger(v) && v >= 0 && v < max ? v : def);
  return {
    body: int(c.body, 3, d.body), color: hex(c.color, SWATCHES, d.color), accent: hex(c.accent, SWATCHES, d.accent), wheels: int(c.wheels, 3, d.wheels),
    number: Number.isInteger(c.number) && c.number >= 0 && c.number <= 99 ? c.number : d.number,
    sticker: int(c.sticker, OPTIONS.sticker.length, d.sticker), skin: hex(c.skin, SKINS, d.skin), suit: hex(c.suit, SWATCHES, d.suit),
    hat: int(c.hat, OPTIONS.hat.length, d.hat), face: int(c.face, 4, d.face), trail: int(c.trail, 5, d.trail), horn: int(c.horn, 5, d.horn),
  };
}

// ---------------- helpers ----------------
const mats = new Map();
function mat(color, opts = {}) {
  const key = color + JSON.stringify(opts);
  if (!mats.has(key)) mats.set(key, new THREE.MeshStandardMaterial({ color, roughness: 0.55, metalness: 0.1, ...opts }));
  return mats.get(key);
}
const texCache = new Map();
function canvasTex(key, w, h, draw) {
  if (texCache.has(key)) return texCache.get(key);
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  texCache.set(key, t); return t;
}
function blobTexture() {
  return canvasTex('blob', 64, 64, (g) => {
    const gr = g.createRadialGradient(32, 32, 4, 32, 32, 30);
    gr.addColorStop(0, 'rgba(0,0,0,.55)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  });
}
function numberTexture(num) {
  return canvasTex('num' + num, 64, 64, (g) => {
    g.fillStyle = '#fff'; g.beginPath(); g.arc(32, 32, 30, 0, 7); g.fill();
    g.fillStyle = '#1b1430'; g.font = 'bold 36px Trebuchet MS, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(String(num), 32, 35);
  });
}
function faceTexture(face) {
  return canvasTex('face' + face, 128, 128, (g) => {
    g.lineCap = 'round'; g.strokeStyle = '#1b1430'; g.fillStyle = '#1b1430'; g.lineWidth = 7;
    const eye = (x, y, r = 8) => { g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(x + 2, y - 3, r * 0.35, 0, 7); g.fill(); g.fillStyle = '#1b1430'; };
    if (face === 0) { // happy
      eye(42, 50); eye(86, 50);
      g.beginPath(); g.arc(64, 70, 24, 0.15 * Math.PI, 0.85 * Math.PI); g.stroke();
      g.fillStyle = 'rgba(255,90,110,.35)'; g.beginPath(); g.arc(28, 72, 9, 0, 7); g.arc(100, 72, 9, 0, 7); g.fill();
    } else if (face === 1) { // cool shades
      g.fillStyle = '#111'; g.beginPath(); g.roundRect(18, 38, 40, 24, 8); g.roundRect(70, 38, 40, 24, 8); g.fill();
      g.fillRect(56, 44, 16, 6);
      g.fillStyle = 'rgba(255,255,255,.5)'; g.fillRect(26, 42, 12, 4); g.fillRect(78, 42, 12, 4);
      g.beginPath(); g.moveTo(48, 92); g.quadraticCurveTo(70, 100, 86, 86); g.stroke();
    } else if (face === 2) { // determined
      eye(42, 56, 7); eye(86, 56, 7);
      g.beginPath(); g.moveTo(26, 36); g.lineTo(54, 44); g.moveTo(102, 36); g.lineTo(74, 44); g.stroke();
      g.beginPath(); g.moveTo(46, 90); g.lineTo(82, 90); g.stroke();
    } else { // cheeky wink + tongue
      eye(42, 52);
      g.beginPath(); g.moveTo(74, 52); g.quadraticCurveTo(86, 44, 98, 52); g.stroke();
      g.beginPath(); g.arc(64, 74, 20, 0.1 * Math.PI, 0.9 * Math.PI); g.stroke();
      g.fillStyle = '#ff5f7e'; g.beginPath(); g.ellipse(70, 96, 9, 11, 0, 0, 7); g.fill();
    }
  });
}
function stickerTexture(kind, color) {
  return canvasTex('st' + kind + color, 128, 128, (g) => {
    g.lineJoin = 'round';
    if (kind === 1) { // star
      g.fillStyle = '#ffd23f'; g.strokeStyle = '#1b1430'; g.lineWidth = 6; g.beginPath();
      for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? 24 : 54; g.lineTo(64 + Math.cos(a) * r, 64 + Math.sin(a) * r); }
      g.closePath(); g.fill(); g.stroke();
    } else if (kind === 2) { // flame
      const grd = g.createLinearGradient(0, 0, 128, 0); grd.addColorStop(0, '#ffd23f'); grd.addColorStop(0.5, '#ff8a1c'); grd.addColorStop(1, '#ef3b4a');
      g.fillStyle = grd; g.beginPath(); g.moveTo(8, 64);
      g.bezierCurveTo(30, 30, 50, 60, 70, 24); g.bezierCurveTo(78, 50, 96, 30, 122, 40); g.bezierCurveTo(100, 60, 120, 80, 122, 92);
      g.bezierCurveTo(90, 86, 70, 104, 40, 96); g.bezierCurveTo(28, 92, 14, 84, 8, 64); g.fill();
    } else if (kind === 3) { // lightning bolt
      g.fillStyle = '#ffe23a'; g.strokeStyle = '#1b1430'; g.lineWidth = 6; g.beginPath();
      g.moveTo(74, 8); g.lineTo(30, 72); g.lineTo(60, 72); g.lineTo(48, 120); g.lineTo(98, 50); g.lineTo(66, 50); g.closePath(); g.fill(); g.stroke();
    } else if (kind === 4) { // flag (simplified)
      g.fillStyle = '#f7e017'; g.fillRect(4, 24, 120, 80);
      g.save(); g.beginPath(); g.rect(4, 24, 120, 80); g.clip();
      g.translate(64, 64); g.rotate(0.42);
      g.fillStyle = '#ffffff'; g.fillRect(-90, -14, 180, 14);
      g.fillStyle = '#111111'; g.fillRect(-90, 0, 180, 13);
      g.restore();
      g.fillStyle = '#cf1126';
      g.beginPath(); g.arc(64, 70, 15, 0.1 * Math.PI, 0.9 * Math.PI); g.lineWidth = 5; g.strokeStyle = '#cf1126'; g.stroke();
      g.fillRect(61, 44, 6, 26); g.beginPath(); g.moveTo(54, 46); g.lineTo(74, 46); g.lineTo(64, 38); g.fill();
      g.strokeStyle = 'rgba(0,0,0,.4)'; g.lineWidth = 3; g.strokeRect(4, 24, 120, 80);
    } else if (kind === 5) { // heart
      g.fillStyle = '#ff3b6b'; g.strokeStyle = '#fff'; g.lineWidth = 6; g.beginPath();
      g.moveTo(64, 112); g.bezierCurveTo(10, 72, 10, 22, 50, 26); g.bezierCurveTo(60, 28, 64, 38, 64, 42);
      g.bezierCurveTo(64, 38, 68, 28, 78, 26); g.bezierCurveTo(118, 22, 118, 72, 64, 112); g.fill(); g.stroke();
    }
  });
}

// ---------------- builder ----------------
// returns { group, body, wheels, driver, shield, tnt, horn (sprite-ish group) }
export function buildKart(custom = {}) {
  const c = { ...DEFAULT_CUSTOM, ...custom };
  const root = new THREE.Group();
  const body = new THREE.Group(); root.add(body);

  const shadow = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 4.6), new THREE.MeshBasicMaterial({ map: blobTexture(), transparent: true, depthWrite: false }));
  shadow.rotation.x = -Math.PI / 2; shadow.position.y = 0.03; root.add(shadow);

  const main = mat(c.color), accent = mat(c.accent), dark = mat('#222831'), metal = mat('#9aa3ad', { metalness: 0.6, roughness: 0.3 });
  let halfW = 0.8, sideY = 0.6, sideZ = -0.2;
  if (c.body === 1) { // rocket
    const ch = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.45, 3.2), main); ch.position.set(0, 0.55, 0.1); body.add(ch);
    const nose = new THREE.Mesh(new THREE.ConeGeometry(0.62, 1.3, 4), main); nose.rotation.x = Math.PI / 2; nose.rotation.y = Math.PI / 4; nose.position.set(0, 0.55, 2.3); body.add(nose);
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.47, 3.22), accent); stripe.position.set(0, 0.56, 0.1); body.add(stripe);
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.8, 0.8), accent); fin.position.set(0, 1.05, -1.3); body.add(fin);
    halfW = 0.75; sideY = 0.55; sideZ = 0.4;
  } else if (c.body === 2) { // buggy
    const ch = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.6, 2.6), main); ch.position.set(0, 0.7, 0); body.add(ch);
    const bar = new THREE.Mesh(new THREE.TorusGeometry(0.75, 0.08, 6, 12, Math.PI), metal); bar.position.set(0, 1.0, -0.55); body.add(bar);
    const bump = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.3, 0.3), accent); bump.position.set(0, 0.55, 1.4); body.add(bump);
    const bump2 = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.3, 0.3), accent); bump2.position.set(0, 0.55, -1.4); body.add(bump2);
    halfW = 0.85; sideY = 0.72; sideZ = 0.2;
  } else { // classic
    const ch = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.5, 2.8), main); ch.position.set(0, 0.6, 0); body.add(ch);
    const nose = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.35, 0.8), accent); nose.position.set(0, 0.55, 1.65); body.add(nose);
    const wing = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.1, 0.5), accent); wing.position.set(0, 1.15, -1.35); body.add(wing);
    for (const sx of [-0.7, 0.7]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.4, 0.1), dark); p.position.set(sx, 0.95, -1.35); body.add(p); }
  }
  // number on the nose
  const num = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 0.6), new THREE.MeshBasicMaterial({ map: numberTexture(c.number), transparent: true }));
  num.rotation.x = -Math.PI / 2; num.position.set(0, c.body === 2 ? 1.01 : 0.88, 0.75); body.add(num);
  // side stickers
  if (c.sticker > 0) {
    const sm = new THREE.MeshBasicMaterial({ map: stickerTexture(c.sticker, c.color), transparent: true, side: THREE.DoubleSide });
    for (const sx of [-1, 1]) {
      const s = new THREE.Mesh(new THREE.PlaneGeometry(0.75, 0.75), sm);
      s.position.set(sx * (halfW + 0.012), sideY, sideZ); s.rotation.y = sx * Math.PI / 2; body.add(s);
    }
  }
  for (const sx of [-0.35, 0.35]) { const ex = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 0.5, 8), metal); ex.rotation.x = Math.PI / 2; ex.position.set(sx, 0.6, -1.55); body.add(ex); }

  // wheels
  const wheels = [];
  const tyreM = mat('#151515');
  const hubCol = [metal, accent, mat('#ffcf3f', { metalness: 0.7, roughness: 0.25 })][c.wheels % 3];
  const wr = c.body === 2 ? 0.5 : 0.42, ww = c.wheels === 1 ? 0.5 : 0.42;
  for (const [x, z] of [[-0.95, 1.05], [0.95, 1.05], [-0.98, -1.05], [0.98, -1.05]]) {
    const w = new THREE.Group();
    const tyre = new THREE.Mesh(new THREE.CylinderGeometry(wr, wr, ww, 14), tyreM); tyre.rotation.z = Math.PI / 2; w.add(tyre);
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(wr * (c.wheels === 1 ? 0.65 : 0.5), wr * 0.5, ww + 0.02, c.wheels === 1 ? 5 : 8), hubCol); hub.rotation.z = Math.PI / 2; w.add(hub);
    w.position.set(x, wr, z); body.add(w); wheels.push(w);
  }

  // driver
  const driver = new THREE.Group(); driver.position.set(0, c.body === 2 ? 0.95 : 0.85, -0.25); body.add(driver);
  const suit = mat(c.suit);
  const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.4, 0.75, 10), suit); torso.position.y = 0.35; driver.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.33, 16, 12), mat(c.skin)); head.position.y = 0.98; driver.add(head);
  const faceM = new THREE.Mesh(new THREE.CircleGeometry(0.26, 20), new THREE.MeshBasicMaterial({ map: faceTexture(c.face), transparent: true }));
  faceM.position.set(0, 0.96, 0.3); driver.add(faceM);
  const hatCol = mat(c.accent);
  if (c.hat === 0) { // helmet + visor strip
    const h = new THREE.Mesh(new THREE.SphereGeometry(0.37, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2.1), mat(c.color)); h.position.y = 1.0; driver.add(h);
    const st = new THREE.Mesh(new THREE.TorusGeometry(0.36, 0.035, 6, 20), hatCol); st.rotation.x = Math.PI / 2; st.position.y = 1.04; driver.add(st);
  } else if (c.hat === 1) { // cap
    const h = new THREE.Mesh(new THREE.SphereGeometry(0.35, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), hatCol); h.position.y = 1.07; driver.add(h);
    const b = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.04, 0.36), hatCol); b.position.set(0, 1.08, 0.36); driver.add(b);
  } else if (c.hat === 2) { // songkok-style
    const h = new THREE.Mesh(new THREE.CylinderGeometry(0.31, 0.33, 0.3, 18), mat('#1b1b1b')); h.position.y = 1.25; driver.add(h);
  } else if (c.hat === 3) { // tudong-style headscarf (open at the face)
    const scarf = mat(c.accent === '#f4f4f4' ? '#f4f4f4' : c.accent, { side: THREE.DoubleSide });
    const h = new THREE.Mesh(new THREE.SphereGeometry(0.37, 18, 12, Math.PI / 2 + 0.75, Math.PI * 2 - 1.5, 0, Math.PI * 0.8), scarf); h.position.y = 0.98; driver.add(h);
    const drape = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.5, 0.42, 18, 1, true), scarf); drape.position.y = 0.66; driver.add(drape);
  } else if (c.hat === 4) { // headband
    const h = new THREE.Mesh(new THREE.TorusGeometry(0.33, 0.06, 6, 18), hatCol); h.rotation.x = Math.PI / 2; h.position.y = 1.1; driver.add(h);
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.34, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2.6), mat('#2b1d14')); hair.position.y = 1.02; driver.add(hair);
  } else { // crown
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.34, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2.6), mat('#2b1d14')); hair.position.y = 1.02; driver.add(hair);
    const h = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.26, 0.25, 6, 1, true), mat('#ffcf3f', { metalness: 0.7, roughness: 0.25, side: THREE.DoubleSide })); h.position.y = 1.3; driver.add(h);
    for (let i = 0; i < 6; i++) { const g = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 4), mat(i % 2 ? '#ef3b4a' : '#2f7ff5')); g.position.set(Math.cos(i) * 0.29, 1.3, Math.sin(i) * 0.29); driver.add(g); }
  }
  for (const sx of [-0.28, 0.28]) { const a = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.6, 6), suit); a.rotation.x = 1.1; a.position.set(sx, 0.45, 0.35); driver.add(a); }
  const sw = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.04, 6, 14), dark); sw.position.set(0, 0.55, 0.6); sw.rotation.x = -0.6; driver.add(sw);

  const shield = new THREE.Mesh(new THREE.SphereGeometry(2.1, 20, 14), new THREE.MeshStandardMaterial({ color: '#7fd8ff', transparent: true, opacity: 0.28, emissive: '#3aa0ff', emissiveIntensity: 0.5, depthWrite: false }));
  shield.position.y = 0.9; shield.visible = false; root.add(shield);

  const tnt = new THREE.Group();
  for (const [x, z] of [[-0.18, 0], [0.18, 0], [0, 0.2]]) { const st = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.8, 10), mat('#d62828')); st.position.set(x, 0, z); tnt.add(st); }
  tnt.add(new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.12, 0.55), mat('#1b1b1b')));
  const fuse = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6), new THREE.MeshBasicMaterial({ color: '#ffdd55' })); fuse.position.y = 0.5; tnt.add(fuse);
  tnt.position.set(0, 1.5, -1.0); tnt.visible = false; tnt.userData.fuse = fuse; body.add(tnt);

  return { group: root, body, wheels, driver, shield, tnt, custom: c };
}
