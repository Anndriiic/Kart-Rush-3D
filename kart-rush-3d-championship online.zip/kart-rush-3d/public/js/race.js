// Kart Rush 3D — race engine: physics, items, AI, split-screen rendering and HUD.
import * as THREE from 'three';
import { buildKart, TRAILS } from './kart.js';
import { TRACKS, HW, buildTrackData, buildTrackScene } from './tracks.js';

// ---------------- tuning ----------------
const MAX_SPEED = 31, BOOST_MAX = 44, ACCEL = 17, TURN = 1.85, KART_R = 1.25;
const WALL = HW - 1.0;
export const ITEMS = {
  turbo:   { icon: '⚡', label: 'Turbo' },
  oil:     { icon: '🛢️', label: 'Oil Slick' },
  zap:     { icon: '💥', label: 'Zapper' },
  drone:   { icon: '🎯', label: 'Homing Drone' },
  shield:  { icon: '🛡️', label: 'Shield' },
  durian:  { icon: '🌰', label: 'Durian Bomb' },
  tnt:     { icon: '🧨', label: 'TNT Bomb' },
  thunder: { icon: '⛈️', label: 'Thunderstorm' },
};
const ROLL_ICONS = Object.values(ITEMS).map(i => i.icon);
const ord = (n) => n + (['th', 'st', 'nd', 'rd'][(n % 100 > 10 && n % 100 < 14) ? 0 : n % 10] || 'th');
export const fmtTime = (t) => { const m = Math.floor(t / 60), s = t - m * 60; return `${m}:${s.toFixed(2).padStart(5, '0')}`; };
const angDiff = (a, b) => { let d = b - a; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return d; };

// cache built tracks between races (expensive to rebuild)
const trackCache = new Map();
function getTrack(def) {
  if (!trackCache.has(def.id)) {
    const T = buildTrackData(def);
    const built = buildTrackScene(T);
    trackCache.set(def.id, { T, built });
  }
  return trackCache.get(def.id);
}

let qTex = null;
function questionTexture() {
  if (qTex) return qTex;
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const g = c.getContext('2d');
  const gr = g.createLinearGradient(0, 0, 128, 128);
  gr.addColorStop(0, '#ff5fa2'); gr.addColorStop(0.5, '#ffcf3f'); gr.addColorStop(1, '#3ad0ff');
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  g.strokeStyle = '#fff'; g.lineWidth = 10; g.strokeRect(5, 5, 118, 118);
  g.fillStyle = '#fff'; g.font = 'bold 90px Trebuchet MS, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText('?', 64, 70);
  qTex = new THREE.CanvasTexture(c); qTex.colorSpace = THREE.SRGBColorSpace;
  return qTex;
}

export class Race {
  constructor({ renderer, hud, trackId, entrants, laps, title, onEvent, sfx }) {
    this.renderer = renderer; this.hud = hud; this.hctx = hud.getContext('2d');
    this.laps = laps; this.title = title || ''; this.onEvent = onEvent || (() => {}); this.sfx = sfx || (() => {});
    const def = TRACKS.find(t => t.id === trackId) || TRACKS[0];
    this.def = def;
    const { T, built } = getTrack(def);
    this.T = T; this.built = built;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(def.sky);
    this.scene.fog = new THREE.Fog(def.fog, def.fogNear || 250, def.fogFar || 900);
    this.scene.add(built.group);
    const hemi = new THREE.HemisphereLight('#ffffff', '#4a7a5a', 1.6); this.scene.add(hemi);
    const sun = new THREE.DirectionalLight('#fff4dd', 2.2); sun.position.set(200, 300, 120); this.scene.add(sun);

    this.phase = 'intro'; this.t = 0; this.phaseT = 0; this.raceT = 0; this.firstFinishT = 0; this.finishedCount = 0;
    this.hazards = []; this.shots = []; this.flashes = [];
    this.racers = entrants.map((e, i) => this.makeRacer(e, i));
    this.viewRacers = this.racers.slice(0, 4);
    this.placeOnGrid();
    this.buildBoxes();
    this.buildParticles();
    this.overviewCam = new THREE.PerspectiveCamera(55, 1, 1, 3000);
    this.ended = false;
    this.updateRanks();
  }

  // ---------------- setup ----------------
  makeRacer(e, i) {
    const k = buildKart({ color: e.color, ...(e.custom || {}) });
    this.scene.add(k.group);
    const cam = new THREE.PerspectiveCamera(70, 1, 0.3, 2500);
    return {
      id: e.id, name: e.name, color: e.color, kind: e.kind, online: e.online !== false,
      model: k, cam, camA: 0, camPos: new THREE.Vector3(), fov: 70,
      x: 0, z: 0, yv: 0, a: 0, vx: 0, vz: 0, idx: 0, lap: 0, pos: i + 1,
      finished: false, finishTime: 0, place: 0,
      inp: { s: 0, d: 0 }, useQueued: false,
      item: null, pending: null, rollT: 0,
      boostT: 0, spinT: 0, invT: 0, shieldT: 0, slowT: 0, splatT: 0, flashT: 0,
      tnt: 0, tntImmune: 0, stuckT: 0,
      drifting: false, driftDir: 0, driftT: 0,
      bot: { skill: e.kind === 'bot' ? 0.88 + Math.random() * 0.09 : 0.92, lane: (Math.random() - 0.5) * 6, laneT: 0, useT: 1 + Math.random() * 3 },
      splats: [], lastStatus: '', tntSec: 0, hornT: 0,
      trail: TRAILS[k.custom.trail] || null, hornType: k.custom.horn || 0,
    };
  }
  placeOnGrid() {
    const T = this.T;
    this.racers.forEach((r, i) => {
      const row = Math.floor(i / 2), col = i % 2;
      const back = 6 + row * 7 + col * 3;
      const idx = T.wrap(-Math.round(back / T.spacing));
      const lat = col === 0 ? -3 : 3;
      const p = T.point(idx, lat);
      r.x = p[0]; r.z = p[1]; r.a = Math.atan2(T.tz[idx], T.tx[idx]); r.camA = r.a;
      r.idx = idx; r.lap = 0;
      this.syncModel(r, 0);
      r.camPos.set(r.x - Math.cos(r.a) * 8, T.y[idx] + 4, r.z - Math.sin(r.a) * 8);
    });
  }
  buildBoxes() {
    this.boxes = [];
    const geo = new THREE.BoxGeometry(1.5, 1.5, 1.5);
    const mt = new THREE.MeshStandardMaterial({ map: questionTexture(), transparent: true, opacity: 0.92, emissive: '#ffffff', emissiveIntensity: 0.25 });
    for (const row of this.built.boxRows) {
      for (const off of [-4.5, -1.5, 1.5, 4.5]) {
        const p = this.T.point(row, off);
        const m = new THREE.Mesh(geo, mt);
        m.position.set(p[0], p[2] + 1.3, p[1]);
        this.scene.add(m);
        this.boxes.push({ x: p[0], z: p[1], y: p[2], mesh: m, respawn: 0 });
      }
    }
  }
  buildParticles() {
    const MAXP = 1500;
    this.pN = MAXP; this.pPos = new Float32Array(MAXP * 3); this.pCol = new Float32Array(MAXP * 3);
    this.pVel = new Float32Array(MAXP * 3); this.pLife = new Float32Array(MAXP); this.pHead = 0;
    for (let i = 0; i < MAXP; i++) this.pPos[i * 3 + 1] = -9999;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pPos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(this.pCol, 3));
    this.pGeo = g;
    const dc = document.createElement('canvas'); dc.width = dc.height = 32;
    const dg = dc.getContext('2d'), grd = dg.createRadialGradient(16, 16, 2, 16, 16, 15);
    grd.addColorStop(0, 'rgba(255,255,255,1)'); grd.addColorStop(0.6, 'rgba(255,255,255,.8)'); grd.addColorStop(1, 'rgba(255,255,255,0)');
    dg.fillStyle = grd; dg.fillRect(0, 0, 32, 32);
    const pts = new THREE.Points(g, new THREE.PointsMaterial({ size: 0.45, map: new THREE.CanvasTexture(dc), vertexColors: true, transparent: true, depthWrite: false, sizeAttenuation: true }));
    pts.frustumCulled = false;
    this.scene.add(pts);
    this._c = new THREE.Color();
  }
  particle(x, y, z, vx, vy, vz, life, color) {
    const i = this.pHead; this.pHead = (this.pHead + 1) % this.pN;
    this.pPos.set([x, y, z], i * 3); this.pVel.set([vx, vy, vz], i * 3); this.pLife[i] = life;
    this._c.set(color); this.pCol.set([this._c.r, this._c.g, this._c.b], i * 3);
  }
  burst(x, y, z, n, color, sp = 8, life = 0.6) {
    for (let k = 0; k < n; k++) this.particle(x, y, z, (Math.random() - 0.5) * sp, Math.random() * sp * 0.7, (Math.random() - 0.5) * sp, life * (0.6 + Math.random() * 0.6), typeof color === 'function' ? color() : color);
  }

  // ---------------- public API ----------------
  setInput(id, s, d) { const r = this.racers.find(x => x.id === id); if (r) { r.inp.s = s; r.inp.d = d; } }
  queueUse(id) { const r = this.racers.find(x => x.id === id); if (r) r.useQueued = true; }
  honk(id) { const r = this.racers.find(x => x.id === id); if (!r || r.hornT > 0.4) return false; r.hornT = 1.2; this.sfx('horn', r.hornType); return true; }
  setOnline(id, on) { const r = this.racers.find(x => x.id === id); if (r) { r.online = on; if (!on) r.inp = { s: 0, d: 0 }; } }
  statusFor(id) {
    const r = this.racers.find(x => x.id === id); if (!r) return null;
    return { ph: this.phase === 'intro' ? 'count' : this.phase, pos: r.pos, n: this.racers.length, lap: Math.max(1, Math.min(this.laps, r.lap)), laps: this.laps,
      item: r.item, roll: r.rollT > 0, fin: r.finished ? r.place : 0, tnt: r.tnt > 0 ? Math.ceil(r.tnt) : 0, shield: r.shieldT > 0 };
  }
  destroy() {
    for (const r of this.racers) this.scene.remove(r.model.group);
    this.scene.remove(this.built.group); // keep cached geometry
  }

  // ---------------- items ----------------
  pickItem(r) {
    const n = this.racers.length;
    const f = n > 1 ? (r.pos - 1) / (n - 1) : 0;
    const w = {
      turbo: 1 + 2 * f, oil: 2.4 - 1.9 * f, zap: 1.4, drone: r.pos > 1 ? 0.3 + 1.8 * f : 0,
      shield: 2 - 1.5 * f, durian: 0.5 + 1.4 * f, tnt: 1.1, thunder: (r.pos === n && n >= 3) ? 0.7 : 0,
    };
    let sum = 0; for (const k in w) sum += Math.max(0, w[k]);
    let x = Math.random() * sum;
    for (const k in w) { x -= Math.max(0, w[k]); if (x <= 0) return k; }
    return 'turbo';
  }
  useItem(r) {
    const it = r.item; if (!it) return;
    r.item = null;
    const fx = Math.cos(r.a), fz = Math.sin(r.a), y = this.T.y[r.idx];
    switch (it) {
      case 'turbo': r.boostT = Math.max(r.boostT, 1.5); this.sfx('boost'); this.fx(r, 'boost'); break;
      case 'oil': this.addHazard('oil', r.x - fx * 3.2, r.z - fz * 3.2, r, 25); this.sfx('drop'); break;
      case 'zap': {
        const sp = Math.max(Math.hypot(r.vx, r.vz) + 26, 58);
        this.addShot('zap', r, fx, fz, sp, 2.6); this.sfx('zap'); break;
      }
      case 'drone': {
        const target = this.racers.find(o => o.pos === r.pos - 1 && !o.finished) || null;
        const s = this.addShot('drone', r, fx, fz, 50, 7); s.target = target; this.sfx('zap'); break;
      }
      case 'shield': r.shieldT = 8; this.sfx('shield'); break;
      case 'durian': {
        // thrown ahead along the track; splats rivals' screens and leaves a stink cloud where it lands
        const land = this.T.wrap(r.idx + 34), lat = this.T.lateral(r.x, r.z, r.idx);
        const p = this.T.point(land, Math.max(-WALL, Math.min(WALL, lat)));
        const mesh = this.durianMesh(); mesh.position.set(r.x, y + 2, r.z); this.scene.add(mesh);
        this.shots.push({ type: 'durianThrow', owner: r, sx: r.x, sz: r.z, sy: y + 2, ex: p[0], ez: p[1], ey: p[2], t: 0, dur: 0.8, mesh, life: 1 });
        this.sfx('throw');
        break;
      }
      case 'tnt': r.tnt = 10; r.tntSec = 11; this.sfx('fuse'); this.fx(r, 'tnt'); break;
      case 'thunder': {
        for (const o of this.racers) {
          if (o === r || o.pos > r.pos || o.finished) continue;
          if (o.shieldT > 0) { o.shieldT = 0; continue; }
          o.slowT = 3; o.flashT = 0.5; o.spinT = Math.max(o.spinT, 0.5);
          this.bolt(o); this.fx(o, 'hit');
        }
        this.sfx('thunder');
        break;
      }
    }
  }
  addHazard(type, x, z, owner, life) {
    const i = this.T.nearest(x, z, owner ? owner.idx : null).i;
    const y = this.T.y[i];
    let mesh;
    if (type === 'oil') {
      mesh = new THREE.Group();
      const m = new THREE.Mesh(new THREE.CircleGeometry(2.1, 18), new THREE.MeshStandardMaterial({ color: '#15121c', roughness: 0.1, metalness: 0.3 }));
      m.rotation.x = -Math.PI / 2; mesh.add(m);
      const sheen = new THREE.Mesh(new THREE.CircleGeometry(0.9, 12), new THREE.MeshBasicMaterial({ color: '#7d5cff', transparent: true, opacity: 0.4 }));
      sheen.rotation.x = -Math.PI / 2; sheen.position.set(-0.5, 0.01, -0.3); mesh.add(sheen);
      mesh.position.set(x, y + 0.04, z);
    } else { // stink cloud
      mesh = new THREE.Group();
      const mt = new THREE.MeshStandardMaterial({ color: '#b8d94a', transparent: true, opacity: 0.45, depthWrite: false, emissive: '#6f8f10', emissiveIntensity: 0.3 });
      for (let k = 0; k < 7; k++) {
        const s = new THREE.Mesh(new THREE.SphereGeometry(1.6 + Math.random() * 1.2, 10, 8), mt);
        s.position.set((Math.random() - 0.5) * 6, 1 + Math.random() * 1.5, (Math.random() - 0.5) * 6); mesh.add(s);
      }
      mesh.position.set(x, y, z);
    }
    this.scene.add(mesh);
    this.hazards.push({ type, x, z, y, owner, grace: 0.7, life, mesh, r: type === 'oil' ? 2.2 : 5 });
  }
  addShot(type, r, fx, fz, sp, life) {
    const y = this.T.y[r.idx];
    let mesh;
    if (type === 'zap') {
      mesh = new THREE.Group();
      mesh.add(new THREE.Mesh(new THREE.SphereGeometry(0.55, 12, 8), new THREE.MeshBasicMaterial({ color: '#fff7a8' })));
      mesh.add(new THREE.Mesh(new THREE.SphereGeometry(1.0, 12, 8), new THREE.MeshBasicMaterial({ color: '#ffe23a', transparent: true, opacity: 0.35, depthWrite: false })));
    } else {
      mesh = new THREE.Group();
      const body = new THREE.Mesh(new THREE.SphereGeometry(0.5, 12, 8), new THREE.MeshStandardMaterial({ color: '#ff3b5c', emissive: '#ff1030', emissiveIntensity: 0.6 })); mesh.add(body);
      for (const [ox, oz] of [[-0.7, -0.7], [0.7, -0.7], [-0.7, 0.7], [0.7, 0.7]]) {
        const rot = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.05, 10), new THREE.MeshBasicMaterial({ color: '#dddddd', transparent: true, opacity: 0.7 }));
        rot.position.set(ox, 0.25, oz); mesh.add(rot);
      }
    }
    mesh.position.set(r.x + fx * 2.5, y + 1, r.z + fz * 2.5);
    this.scene.add(mesh);
    const s = { type, owner: r, x: r.x + fx * 2.5, z: r.z + fz * 2.5, y: y + 1, vx: fx * sp, vz: fz * sp, sp, life, max: life, bounces: 2, idx: r.idx, mesh };
    this.shots.push(s);
    return s;
  }
  durianMesh() {
    const g = new THREE.Group();
    const core = new THREE.Mesh(new THREE.SphereGeometry(0.8, 12, 10), new THREE.MeshStandardMaterial({ color: '#8fae2a', flatShading: true }));
    g.add(core);
    const spikeM = new THREE.MeshStandardMaterial({ color: '#6d8a1c', flatShading: true });
    const ico = new THREE.IcosahedronGeometry(0.8, 0).attributes.position;
    for (let i = 0; i < ico.count; i += 3) {
      const v = new THREE.Vector3(ico.getX(i), ico.getY(i), ico.getZ(i)).normalize();
      const sp = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.45, 4), spikeM);
      sp.position.copy(v.clone().multiplyScalar(0.85)); sp.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), v); g.add(sp);
    }
    return g;
  }
  bolt(o) {
    const y = this.T.y[o.idx];
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.35, 60, 0.35), new THREE.MeshBasicMaterial({ color: '#fffbe0' }));
    m.position.set(o.x, y + 30, o.z); this.scene.add(m);
    this.flashes.push({ mesh: m, life: 0.25 });
    this.burst(o.x, y + 1, o.z, 20, '#fff59a', 10, 0.5);
  }
  hit(r, dur = 1.2, byShieldable = true) {
    if (r.finished && this.phase !== 'race') return false;
    if (r.invT > 0 || r.spinT > 0) return false;
    if (byShieldable && r.shieldT > 0) { r.shieldT = 0; this.sfx('shieldbreak'); this.burst(r.x, this.T.y[r.idx] + 1, r.z, 14, '#7fd8ff', 9); return false; }
    r.spinT = dur; r.invT = dur + 1.2; r.boostT = 0; r.drifting = false; r.driftT = 0;
    r.vx *= 0.3; r.vz *= 0.3;
    this.burst(r.x, this.T.y[r.idx] + 1, r.z, 18, '#ffe36b', 10);
    this.sfx('hit'); this.fx(r, 'hit');
    return true;
  }
  fx(r, k) { this.onEvent('fx', { id: r.id, k }); }

  // ---------------- AI ----------------
  botInput(r, dt) {
    const T = this.T, b = r.bot;
    b.laneT -= dt;
    if (b.laneT <= 0) { b.lane = (Math.random() - 0.5) * 7; b.laneT = 2 + Math.random() * 3; }
    let lane = b.lane;
    // TNT holder hunts the nearest rival ahead
    if (r.tnt > 0) {
      let best = null, bd = 60;
      for (const o of this.racers) {
        if (o === r || o.finished) continue;
        const d = Math.hypot(o.x - r.x, o.z - r.z);
        const ahead = (o.x - r.x) * Math.cos(r.a) + (o.z - r.z) * Math.sin(r.a) > -2;
        if (ahead && d < bd) { bd = d; best = o; }
      }
      if (best) lane = T.lateral(best.x, best.z, best.idx);
    }
    // dodge hazards ahead
    for (const h of this.hazards) {
      const dx = h.x - r.x, dz = h.z - r.z, d = Math.hypot(dx, dz);
      if (d < 25 && dx * Math.cos(r.a) + dz * Math.sin(r.a) > 0) {
        const hl = T.lateral(h.x, h.z, r.idx);
        if (Math.abs(hl - lane) < 3.5) lane = hl > 0 ? hl - 4 : hl + 4;
      }
    }
    lane = Math.max(-WALL + 0.8, Math.min(WALL - 0.8, lane));
    const sp = Math.hypot(r.vx, r.vz);
    const ahead = T.wrap(r.idx + 9 + Math.round(sp * 0.35));
    const p = T.point(ahead, lane);
    const want = Math.atan2(p[1] - r.z, p[0] - r.x);
    r.inp.s = Math.max(-1, Math.min(1, angDiff(r.a, want) * 2.4));
    r.inp.d = 0;
    if (r.item && r.rollT <= 0) {
      b.useT -= dt;
      if (b.useT <= 0) { r.useQueued = true; b.useT = 1 + Math.random() * 4; }
    }
  }

  // ---------------- simulation ----------------
  stepRacer(r, dt) {
    const T = this.T;
    const racing = this.phase === 'race';
    const auto = r.kind === 'bot' || r.finished || !r.online;
    if (auto) this.botInput(r, dt);
    const control = racing && r.spinT <= 0;
    const steer = r.inp.s, drift = r.inp.d;

    if (r.useQueued) { r.useQueued = false; if (control && r.item && r.rollT <= 0) this.useItem(r); }
    if (r.rollT > 0) { r.rollT -= dt; if (r.rollT <= 0) { r.item = r.pending; r.pending = null; this.fx(r, 'item'); } }

    const fx = Math.cos(r.a), fz = Math.sin(r.a);
    let speed = r.vx * fx + r.vz * fz;
    const absSp = Math.hypot(r.vx, r.vz);

    // drift
    if (control && drift && Math.abs(steer) > 0.3 && speed > 16) {
      if (!r.drifting) { r.drifting = true; r.driftDir = Math.sign(steer); r.driftT = 0; }
    }
    if (r.drifting && (!drift || !control || speed < 11)) {
      if (r.driftT > 0.7 && control) { r.boostT = Math.max(r.boostT, r.driftT > 1.6 ? 1.0 : 0.55); this.sfx('boost'); this.fx(r, 'boost'); }
      r.drifting = false; r.driftT = 0;
    }
    if (r.drifting) r.driftT += dt;

    // steering
    if (control) {
      const turn = TURN * Math.max(0.5, Math.min(1, Math.abs(speed) / 14));
      let s = steer;
      if (r.drifting) s = r.driftDir * (0.65 + 0.45 * Math.max(0, steer * r.driftDir));
      r.a += s * turn * (r.drifting ? 1.2 : 1) * dt;
    }
    if (r.spinT > 0) { r.spinT -= dt; r.a += 11 * dt; }

    // thrust & speed caps
    let maxSp = MAX_SPEED;
    if (r.kind === 'bot' || !r.online || r.finished) maxSp *= r.bot.skill;
    if (r.tnt > 0) maxSp *= 1.1;
    if (r.slowT > 0) { r.slowT -= dt; maxSp *= 0.55; }
    if (r.boostT > 0) { r.boostT -= dt; maxSp = BOOST_MAX; }
    for (const k of ['invT', 'shieldT', 'splatT', 'flashT', 'tntImmune']) if (r[k] > 0) r[k] -= dt;
    if (racing && r.spinT <= 0) {
      const acc = r.boostT > 0 ? ACCEL * 3 : ACCEL;
      if (speed < maxSp) { r.vx += fx * acc * dt; r.vz += fz * acc * dt; }
    }
    if (absSp > maxSp) { const k = Math.max(0, 1 - 1.6 * dt); r.vx *= k; r.vz *= k; }
    if (!racing) { r.vx *= Math.max(0, 1 - 3 * dt); r.vz *= Math.max(0, 1 - 3 * dt); }
    speed = r.vx * fx + r.vz * fz;
    const lx = r.vx - fx * speed, lz = r.vz - fz * speed;
    const grip = r.spinT > 0 ? 1.5 : r.drifting ? 2.4 : 8;
    const g = Math.min(1, grip * dt);
    r.vx -= lx * g; r.vz -= lz * g;
    r.x += r.vx * dt; r.z += r.vz * dt;

    // rails
    const n = T.nearest(r.x, r.z, r.idx);
    const lat = T.lateral(r.x, r.z, n.i);
    if (Math.abs(lat) > WALL) {
      const sg = Math.sign(lat), nx = -T.tz[n.i] * sg, nz = T.tx[n.i] * sg, over = Math.abs(lat) - WALL;
      r.x -= nx * over; r.z -= nz * over;
      const vn = r.vx * nx + r.vz * nz;
      if (vn > 0) { r.vx -= nx * vn * 1.4; r.vz -= nz * vn * 1.4; r.vx *= 0.85; r.vz *= 0.85; if (vn > 8) this.burst(r.x + nx, T.y[n.i] + 0.6, r.z + nz, 6, '#ffffff', 5, 0.3); }
      if (Math.cos(r.a) * nx + Math.sin(r.a) * nz > 0.2 && r.spinT <= 0) r.a += angDiff(r.a, Math.atan2(T.tz[n.i], T.tx[n.i])) * Math.min(1, 5 * dt);
    }
    // rescue if stuck
    if (racing && r.spinT <= 0 && Math.hypot(r.vx, r.vz) < 3) {
      r.stuckT += dt;
      if (r.stuckT > 2) { const i = T.wrap(n.i + 3); const p = T.point(i, 0); r.x = p[0]; r.z = p[1]; r.a = Math.atan2(T.tz[i], T.tx[i]); r.vx = r.vz = 0; r.invT = 1.5; r.stuckT = 0; }
    } else r.stuckT = 0;

    // laps
    const prev = r.idx; r.idx = n.i;
    const d = r.idx - prev;
    if (d < -T.N / 2) r.lap++; else if (d > T.N / 2) r.lap--;
    if (racing && !r.finished && r.lap > this.laps) {
      r.finished = true; r.finishTime = this.raceT; r.place = ++this.finishedCount; r.tnt = 0;
      if (!this.firstFinishT) this.firstFinishT = this.raceT;
      this.onEvent('finish', { id: r.id, place: r.place, time: r.finishTime });
      this.fx(r, 'finish'); this.sfx('finish');
    }
    if (racing && !r.finished && r.lap === this.laps && prev !== r.idx && d < -T.N / 2) { r.finalLapT = 2.5; this.sfx('finallap'); }
    if (r.finalLapT > 0) r.finalLapT -= dt;

    // TNT fuse
    if (r.tnt > 0) {
      r.tnt -= dt;
      const sec = Math.ceil(r.tnt);
      if (sec !== r.tntSec) { r.tntSec = sec; this.fx(r, 'tick' + sec); }
      if (r.tnt <= 0) this.explodeTNT(r);
    }

    // effects
    const y = T.y[r.idx];
    if (r.boostT > 0) for (let k = 0; k < 2; k++) this.particle(r.x - fx * 2, y + 0.7, r.z - fz * 2, -fx * 6 + (Math.random() - 0.5) * 3, Math.random() * 2, -fz * 6 + (Math.random() - 0.5) * 3, 0.35, r.trail ? r.trail[Math.random() < 0.5 ? 0 : 1] : `hsl(${Math.floor(Math.random() * 360)},95%,60%)`);
    if (r.hornT > 0) r.hornT -= dt;
    if (r.drifting) {
      const c = r.driftT > 1.6 ? '#ff9a2e' : r.driftT > 0.7 ? '#46b3ff' : '#ffffff';
      const sx = -fz * r.driftDir, sz = fx * r.driftDir;
      this.particle(r.x - fx * 1.2 - sx * 1.0, y + 0.3, r.z - fz * 1.2 - sz * 1.0, (Math.random() - 0.5) * 4, Math.random() * 3, (Math.random() - 0.5) * 4, 0.3, c);
    }
    if (r.slowT > 0 && Math.random() < 0.1) this.particle(r.x, y + 2.2, r.z, (Math.random() - 0.5) * 2, 2, (Math.random() - 0.5) * 2, 0.8, '#b8d94a');
  }
  explodeTNT(r) {
    r.tnt = 0;
    const y = this.T.y[r.idx];
    this.burst(r.x, y + 1, r.z, 60, () => (Math.random() < 0.5 ? '#ff7b00' : Math.random() < 0.5 ? '#ffd23f' : '#3a3a3a'), 18, 0.9);
    const ring = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), new THREE.MeshBasicMaterial({ color: '#ffb02e', transparent: true, opacity: 0.6, depthWrite: false }));
    ring.position.set(r.x, y + 1, r.z); this.scene.add(ring); this.flashes.push({ mesh: ring, life: 0.45, grow: 16 });
    r.invT = 0; r.spinT = 0; r.shieldT = 0;
    this.hit(r, 2.0, false);
    for (const o of this.racers) if (o !== r && Math.hypot(o.x - r.x, o.z - r.z) < 7) this.hit(o, 1.0, true);
    this.sfx('boom'); this.fx(r, 'boom');
  }

  step(dt) {
    this.t += dt; this.phaseT += dt;
    if (this.phase === 'intro' && this.phaseT > 3) { this.phase = 'count'; this.phaseT = 0; this.countShown = 4; this.onEvent('phase', 'count'); }
    if (this.phase === 'count') {
      const left = 3 - Math.floor(this.phaseT);
      if (left !== this.countShown) { this.countShown = left; this.sfx(left > 0 ? 'beep' : 'go'); }
      if (this.phaseT >= 3) { this.phase = 'race'; this.phaseT = 0; this.raceT = 0; this.goT = 1; this.onEvent('phase', 'race'); }
    }
    if (this.phase === 'race') this.raceT += dt;
    if (this.goT > 0) this.goT -= dt;

    for (const r of this.racers) this.stepRacer(r, dt);

    // kart collisions (+ TNT passing)
    const R = this.racers;
    for (let i = 0; i < R.length; i++) for (let j = i + 1; j < R.length; j++) {
      const a = R[i], b = R[j];
      const dx = b.x - a.x, dz = b.z - a.z, d2 = dx * dx + dz * dz, min = KART_R * 2;
      if (d2 < min * min && d2 > 1e-4) {
        const d = Math.sqrt(d2), nx = dx / d, nz = dz / d, over = (min - d) / 2;
        a.x -= nx * over; a.z -= nz * over; b.x += nx * over; b.z += nz * over;
        const rv = (b.vx - a.vx) * nx + (b.vz - a.vz) * nz;
        if (rv < 0) { const imp = -rv * 0.8; a.vx -= nx * imp / 2; a.vz -= nz * imp / 2; b.vx += nx * imp / 2; b.vz += nz * imp / 2; }
        if (this.phase === 'race') {
          if (a.tnt > 0 && b.tnt <= 0) this.passTNT(a, b);
          else if (b.tnt > 0 && a.tnt <= 0) this.passTNT(b, a);
        }
      }
    }

    if (this.phase === 'race') {
      // item boxes
      for (const bx of this.boxes) {
        if (bx.respawn > 0) { bx.respawn -= dt; bx.mesh.visible = bx.respawn <= 0; continue; }
        for (const r of R) {
          if (r.finished) continue;
          if ((r.x - bx.x) ** 2 + (r.z - bx.z) ** 2 < (KART_R + 1.0) ** 2) {
            bx.respawn = 2.5; bx.mesh.visible = false;
            this.burst(bx.x, bx.y + 1.3, bx.z, 14, () => `hsl(${Math.random() * 360},90%,65%)`, 9);
            if (!r.item && r.rollT <= 0 && r.tnt <= 0) { r.pending = this.pickItem(r); r.rollT = 1.1; this.sfx('box'); this.fx(r, 'roll'); }
            break;
          }
        }
      }
      // hazards
      for (const h of this.hazards) {
        h.life -= dt; h.grace -= dt;
        for (const r of R) {
          if (r === h.owner && h.grace > 0) continue;
          if ((r.x - h.x) ** 2 + (r.z - h.z) ** 2 < (h.r + 0.6) ** 2) {
            if (h.type === 'oil') { if (this.hit(r, 1.2) || r.shieldT <= 0) h.life = 0; else h.life = 0; }
            else if (h.type === 'cloud' && r.shieldT <= 0) { if (r.slowT < 0.5) this.fx(r, 'stink'); r.slowT = Math.max(r.slowT, 1.2); }
          }
        }
        if (h.type === 'cloud') { h.mesh.rotation.y += dt * 0.6; if (Math.random() < 0.15) this.particle(h.x + (Math.random() - 0.5) * 8, h.y + 2.5, h.z + (Math.random() - 0.5) * 8, 0, 1.5, 0, 1.0, '#c8e05a'); }
      }
      // shots
      for (const s of this.shots) this.stepShot(s, dt);
    }
    this.hazards = this.hazards.filter(h => { if (h.life <= 0) { this.scene.remove(h.mesh); return false; } return true; });
    this.shots = this.shots.filter(s => { if (s.life <= 0) { this.scene.remove(s.mesh); return false; } return true; });
    this.flashes = this.flashes.filter(f => { f.life -= dt; if (f.grow) { const k = f.mesh.scale.x + f.grow * dt * 2; f.mesh.scale.set(k, k, k); f.mesh.material.opacity = Math.max(0, f.life); } if (f.life <= 0) { this.scene.remove(f.mesh); return false; } return true; });

    // particles
    for (let i = 0; i < this.pN; i++) {
      if (this.pLife[i] <= 0) continue;
      this.pLife[i] -= dt;
      if (this.pLife[i] <= 0) { this.pPos[i * 3 + 1] = -9999; continue; }
      this.pPos[i * 3] += this.pVel[i * 3] * dt; this.pPos[i * 3 + 1] += this.pVel[i * 3 + 1] * dt; this.pPos[i * 3 + 2] += this.pVel[i * 3 + 2] * dt;
      this.pVel[i * 3 + 1] -= 4 * dt;
    }
    this.pGeo.attributes.position.needsUpdate = true; this.pGeo.attributes.color.needsUpdate = true;

    if (this.phase === 'race') {
      this.updateRanks();
      const all = R.every(r => r.finished);
      const timeout = this.firstFinishT && this.raceT - this.firstFinishT > 30;
      const hardCap = this.raceT > this.laps * 110;
      if (all || timeout || hardCap) this.finish();
    }
  }
  passTNT(from, to) {
    if (to.tntImmune > 0 || to.finished) return;
    if (to.shieldT > 0) { this.sfx('shield'); return; }
    to.tnt = from.tnt; to.tntSec = 99; from.tnt = 0; from.tntImmune = 1.0;
    this.burst((from.x + to.x) / 2, this.T.y[to.idx] + 1.5, (from.z + to.z) / 2, 12, '#ff3b3b', 8, 0.4);
    this.sfx('pass'); this.fx(to, 'tnt'); this.fx(from, 'passed');
  }
  stepShot(s, dt) {
    const T = this.T;
    s.life -= dt;
    if (s.type === 'durianThrow') {
      s.t += dt; const k = Math.min(1, s.t / s.dur);
      s.mesh.position.set(s.sx + (s.ex - s.sx) * k, s.sy + (s.ey - s.sy) * k + Math.sin(k * Math.PI) * 9, s.sz + (s.ez - s.sz) * k);
      s.mesh.rotation.x += dt * 8; s.mesh.rotation.z += dt * 5;
      if (k >= 1) {
        s.life = 0;
        this.addHazard('cloud', s.ex, s.ez, s.owner, 8);
        this.burst(s.ex, s.ey + 1, s.ez, 30, () => (Math.random() < 0.5 ? '#f3e27a' : '#9bbf2a'), 12, 0.8);
        for (const o of this.racers) if (o !== s.owner && !o.finished) {
          if (o.shieldT > 0) continue;
          o.splatT = 3; o.splats = Array.from({ length: 7 }, () => ({ x: Math.random(), y: Math.random() * 0.8 + 0.1, r: 0.12 + Math.random() * 0.16, rot: Math.random() * 6 }));
          this.fx(o, 'splat');
        }
        this.sfx('splat');
      }
      return;
    }
    if (s.type === 'drone' && s.target && !s.target.finished) {
      const want = Math.atan2(s.target.z - s.z, s.target.x - s.x), cur = Math.atan2(s.vz, s.vx);
      const na = cur + Math.max(-4 * dt, Math.min(4 * dt, angDiff(cur, want)));
      s.vx = Math.cos(na) * s.sp; s.vz = Math.sin(na) * s.sp;
    }
    s.x += s.vx * dt; s.z += s.vz * dt;
    const n = T.nearest(s.x, s.z, s.idx); s.idx = n.i;
    s.y += ((T.y[n.i] + (s.type === 'drone' ? 2.2 : 1)) - s.y) * Math.min(1, dt * 6);
    if (s.type === 'zap') {
      const lat = T.lateral(s.x, s.z, n.i);
      if (Math.abs(lat) > WALL + 0.5) {
        if (s.bounces-- <= 0) { s.life = 0; return; }
        const sg = Math.sign(lat), nx = -T.tz[n.i] * sg, nz = T.tx[n.i] * sg, vn = s.vx * nx + s.vz * nz;
        s.vx -= 2 * vn * nx; s.vz -= 2 * vn * nz; this.sfx('bounce');
      }
      if (Math.random() < 0.7) this.particle(s.x, s.y, s.z, 0, 0.5, 0, 0.25, '#fff27a');
    } else {
      if (Math.random() < 0.5) this.particle(s.x, s.y, s.z, 0, -1, 0, 0.3, '#ff6b81');
      s.mesh.children.forEach((c, i) => { if (i > 0) c.rotation.y += dt * 40; });
    }
    s.mesh.position.set(s.x, s.y, s.z);
    for (const r of this.racers) {
      if (r === s.owner && s.max - s.life < 0.35) continue;
      if ((r.x - s.x) ** 2 + (r.z - s.z) ** 2 < (KART_R + 0.9) ** 2) { this.hit(r, 1.2); s.life = 0; this.burst(s.x, s.y, s.z, 16, '#fff27a', 10); break; }
    }
  }
  updateRanks() {
    const prog = (r) => r.finished ? 1e9 - r.place : r.lap * this.T.N + r.idx;
    [...this.racers].sort((a, b) => prog(b) - prog(a)).forEach((r, i) => { r.pos = i + 1; });
  }
  finish() {
    if (this.ended) return;
    this.ended = true; this.phase = 'done'; this.phaseT = 0;
    this.updateRanks();
    const order = [...this.racers].sort((a, b) => a.pos - b.pos);
    const results = order.map((r, i) => ({ id: r.id, name: r.name, color: r.color, kind: r.kind, place: i + 1, finished: r.finished, time: r.finished ? r.finishTime : null, progress: r.lap * this.T.N + r.idx }));
    for (const r of this.racers) { r.tnt = 0; r.place = results.find(x => x.id === r.id).place; }
    this.sfx('fanfare');
    this.onEvent('done', { results });
  }

  // ---------------- visuals ----------------
  syncModel(r, dt) {
    const T = this.T, m = r.model;
    const y = T.y[r.idx];
    m.group.position.set(r.x, y, r.z);
    m.group.rotation.y = Math.PI / 2 - r.a + (r.drifting ? -r.driftDir * 0.3 : 0);
    const i0 = T.wrap(r.idx - 3), i1 = T.wrap(r.idx + 3);
    m.body.rotation.x = -Math.atan2(T.y[i1] - T.y[i0], 6);
    const sp = r.vx * Math.cos(r.a) + r.vz * Math.sin(r.a);
    for (const w of m.wheels) w.rotation.x += sp * dt / 0.45;
    m.shield.visible = r.shieldT > 0;
    if (m.shield.visible) m.shield.material.opacity = 0.18 + Math.sin(this.t * 10) * 0.08 + (r.shieldT < 2 ? Math.sin(this.t * 30) * 0.1 : 0);
    m.tnt.visible = r.tnt > 0;
    if (r.tnt > 0) { const fl = Math.sin(this.t * (8 + (10 - r.tnt) * 3)) > 0; m.tnt.userData.fuse.material.color.set(fl ? '#ffffff' : '#ff3300'); m.tnt.scale.setScalar(1 + (r.tnt < 3 ? Math.sin(this.t * 25) * 0.12 : 0)); }
    m.group.visible = !(r.invT > 0 && r.spinT <= 0 && Math.floor(this.t * 12) % 2);
  }
  updateVisuals(dt) {
    const T = this.T;
    for (const r of this.racers) {
      this.syncModel(r, dt);
      // chase camera
      if (r.spinT <= 0) r.camA += angDiff(r.camA, r.a) * Math.min(1, dt * 5);
      const ca = this.phase === 'intro' ? r.a : r.camA;
      const y = T.y[r.idx];
      const want = new THREE.Vector3(r.x - Math.cos(ca) * 7.5, y + 3.3, r.z - Math.sin(ca) * 7.5);
      r.camPos.lerp(want, Math.min(1, dt * 8));
      r.cam.position.copy(r.camPos);
      r.cam.lookAt(r.x + Math.cos(ca) * 5, y + 1.3, r.z + Math.sin(ca) * 5);
      const targetFov = r.boostT > 0 ? 82 : 70;
      r.fov += (targetFov - r.fov) * Math.min(1, dt * 4);
      if (Math.abs(r.cam.fov - r.fov) > 0.05) { r.cam.fov = r.fov; r.cam.updateProjectionMatrix(); }
    }
    for (const b of this.boxes) { b.mesh.rotation.y += dt * 1.6; b.mesh.rotation.x = 0.4; b.mesh.position.y = b.y + 1.3 + Math.sin(this.t * 3 + b.x) * 0.15; }
    if (this.built.water) this.built.water.offset.set(this.t * 0.01, this.t * 0.006);
    const boats = this.built.group.userData.boats;
    if (boats) boats.children.forEach(b => { b.position.y = -0.35 + Math.sin(this.t * 1.5 + b.userData.phase) * 0.12; b.rotation.z = Math.sin(this.t + b.userData.phase) * 0.05; });
    // overview camera slowly orbits
    const oa = this.t * 0.08;
    this.overviewCam.position.set(Math.cos(oa) * 330, 230, Math.sin(oa) * 260);
    this.overviewCam.lookAt(0, 0, 0);
  }

  layout(W, H) {
    const n = this.viewRacers.length;
    if (n === 1) return [{ r: this.viewRacers[0], x: 0, y: 0, w: W, h: H }];
    if (n === 2) return this.viewRacers.map((r, i) => ({ r, x: 0, y: i * H / 2, w: W, h: H / 2 }));
    const w = W / 2, h = H / 2;
    const v = [0, 1, 2, 3].map(i => ({ r: this.viewRacers[i] || null, x: (i % 2) * w, y: Math.floor(i / 2) * h, w, h, mirror: i % 2 === 1 }));
    return v;
  }
  render(W, H, dt) {
    this.updateVisuals(dt);
    const rd = this.renderer;
    rd.setScissorTest(true);
    const views = this.layout(W, H);
    for (const v of views) {
      const cam = v.r ? v.r.cam : this.overviewCam;
      const asp = v.w / v.h;
      if (Math.abs(cam.aspect - asp) > 1e-3) { cam.aspect = asp; cam.updateProjectionMatrix(); }
      const yb = H - v.y - v.h; // WebGL origin bottom-left
      rd.setViewport(v.x, yb, v.w, v.h); rd.setScissor(v.x, yb, v.w, v.h);
      rd.render(this.scene, cam);
    }
    rd.setScissorTest(false);
    this.drawHUD(views, W, H);
  }

  // ---------------- HUD ----------------
  drawHUD(views, W, H) {
    const g = this.hctx, dpr = this.hud.width / W;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, W, H);
    for (const v of views) {
      g.save(); g.beginPath(); g.rect(v.x, v.y, v.w, v.h); g.clip();
      if (v.r) this.drawRacerHUD(g, v); else this.drawOverviewHUD(g, v);
      g.restore();
    }
    // split lines
    g.fillStyle = '#1b1430';
    if (views.length >= 2) { if (views.length === 2) g.fillRect(0, H / 2 - 3, W, 6); else { g.fillRect(W / 2 - 3, 0, 6, H); g.fillRect(0, H / 2 - 3, W, 6); } }
    // centre: minimap for 4-way
    if (views.length === 4 && views.every(v => v.r)) this.drawMinimap(g, W / 2 - 75, H / 2 - 75, 150, 150, true);
    // top centre timer / title
    const fs = Math.max(14, Math.min(22, W / 70));
    if (this.phase === 'race' || this.phase === 'done') {
      const txt = fmtTime(this.raceT);
      g.font = `800 ${fs}px Trebuchet MS, sans-serif`; const tw = g.measureText(txt).width + 24;
      const ty = views.length === 4 ? H / 2 - 75 - fs - 22 : 8;
      g.fillStyle = 'rgba(20,14,40,.8)'; g.beginPath(); g.roundRect(W / 2 - tw / 2, ty, tw, fs + 14, 10); g.fill();
      g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(txt, W / 2, ty + (fs + 14) / 2 + 1);
      if (this.firstFinishT && this.phase === 'race') {
        const left = Math.max(0, 30 - (this.raceT - this.firstFinishT));
        g.fillStyle = '#ff6b8a'; g.font = `800 ${fs * 0.8}px Trebuchet MS, sans-serif`; g.fillText(`race ends in ${Math.ceil(left)}s`, W / 2, ty + fs + 30);
      }
    }
    // intro banner
    if (this.phase === 'intro') {
      const a = Math.min(1, this.phaseT * 2) * Math.min(1, (3 - this.phaseT) * 2);
      g.globalAlpha = Math.max(0, a);
      g.fillStyle = 'rgba(20,14,40,.85)'; g.fillRect(0, H / 2 - 90, W, 180);
      g.fillStyle = '#ffcf3f'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.font = `italic 900 ${Math.min(72, W / 16)}px Trebuchet MS, sans-serif`; g.fillText(this.def.name.toUpperCase(), W / 2, H / 2 - 22);
      g.fillStyle = '#fff'; g.font = `700 ${Math.min(28, W / 40)}px Trebuchet MS, sans-serif`;
      g.fillText(`${this.title}  •  ${this.laps} ${this.laps === 1 ? 'lap' : 'laps'}`, W / 2, H / 2 + 40);
      g.globalAlpha = 1;
    }
    // countdown
    if (this.phase === 'count' || this.goT > 0) {
      const n = this.phase === 'count' ? 3 - Math.floor(this.phaseT) : 0;
      const txt = n > 0 ? String(n) : 'GO!';
      const k = this.phase === 'count' ? this.phaseT % 1 : 1 - this.goT;
      const size = Math.min(W, H) * (0.35 - k * 0.12);
      g.globalAlpha = 1 - k * 0.7;
      g.font = `italic 900 ${size}px Trebuchet MS, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.lineWidth = size / 14; g.strokeStyle = '#1b1430'; g.strokeText(txt, W / 2, H / 2);
      g.fillStyle = n > 0 ? '#ffffff' : '#ffcf3f'; g.fillText(txt, W / 2, H / 2);
      g.globalAlpha = 1;
    }
  }
  drawRacerHUD(g, v) {
    const r = v.r, s = Math.min(v.w / 900, v.h / 500) * 1.15 + 0.25;
    const x0 = v.x, y0 = v.y, w = v.w, h = v.h;
    // durian splat
    if (r.splatT > 0) {
      g.globalAlpha = Math.min(1, r.splatT / 0.8) * 0.92;
      for (const sp of r.splats) {
        const cx = x0 + sp.x * w, cy = y0 + sp.y * h, rad = sp.r * Math.min(w, h) * 1.4;
        g.fillStyle = '#e9d36a'; g.beginPath();
        for (let k = 0; k < 14; k++) { const a = sp.rot + k / 14 * Math.PI * 2, rr = rad * (k % 2 ? 0.75 : 1.05); g.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr); }
        g.fill();
        g.fillStyle = '#c9a93c'; g.beginPath(); g.arc(cx, cy, rad * 0.45, 0, 7); g.fill();
      }
      g.globalAlpha = 1;
    }
    if (r.slowT > 0) { g.fillStyle = 'rgba(160,200,40,.18)'; g.fillRect(x0, y0, w, h); }
    if (r.flashT > 0) { g.fillStyle = `rgba(255,255,230,${r.flashT})`; g.fillRect(x0, y0, w, h); }
    // name tags of others
    const v3 = new THREE.Vector3();
    for (const o of this.racers) {
      if (o === r) continue;
      const d = Math.hypot(o.x - r.x, o.z - r.z); if (d > 140) continue;
      v3.set(o.x, this.T.y[o.idx] + 3.4, o.z).project(r.cam);
      if (v3.z > 1 || Math.abs(v3.x) > 1.1 || Math.abs(v3.y) > 1.1) continue;
      const sx = x0 + (v3.x + 1) / 2 * w, sy = y0 + (1 - v3.y) / 2 * h;
      const fs = Math.max(10, 15 * s * Math.max(0.6, 1 - d / 160));
      g.font = `800 ${fs}px Trebuchet MS, sans-serif`;
      const label = (o.hornT > 0 ? '📢 ' : '') + o.name + (o.tnt > 0 ? ' 🧨' : '');
      const tw = g.measureText(label).width + 10;
      g.fillStyle = 'rgba(20,14,40,.7)'; g.beginPath(); g.roundRect(sx - tw / 2, sy - fs - 4, tw, fs + 6, 5); g.fill();
      g.fillStyle = o.color; g.fillRect(sx - tw / 2, sy + 1, tw, 2);
      g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'alphabetic'; g.fillText(label, sx, sy - 2);
    }
    // name strip
    g.fillStyle = r.color; g.fillRect(x0, y0, w, 5 * s);
    g.font = `800 ${16 * s}px Trebuchet MS, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'top';
    const nm = (r.hornT > 0 ? '📢 ' : '') + r.name + (r.online || r.kind === 'bot' ? '' : '  (autopilot)');
    const nw = g.measureText(nm).width + 20 * s;
    g.fillStyle = 'rgba(20,14,40,.75)'; g.beginPath(); g.roundRect(x0 + w / 2 - nw / 2, y0 + 5 * s, nw, 24 * s, [0, 0, 8, 8]); g.fill();
    g.fillStyle = '#fff'; g.fillText(nm, x0 + w / 2, y0 + 9 * s);
    // lap
    const mir = !!v.mirror;
    g.textAlign = mir ? 'right' : 'left'; g.textBaseline = 'top';
    g.font = `italic 900 ${26 * s}px Trebuchet MS, sans-serif`;
    const lap = Math.max(1, Math.min(this.laps, r.lap));
    this.outlined(g, `LAP ${lap}/${this.laps}`, mir ? x0 + w - 16 * s : x0 + 16 * s, y0 + 16 * s, '#fff');
    g.textAlign = 'left';
    // position
    g.textBaseline = 'bottom';
    g.font = `italic 900 ${64 * s}px Trebuchet MS, sans-serif`;
    const pcol = r.pos === 1 ? '#ffcf3f' : r.pos === 2 ? '#e4ebf5' : r.pos === 3 ? '#f2a46b' : '#ffffff';
    const pt = String(r.pos), suf = ord(r.pos).slice(pt.length);
    const pw = g.measureText(pt).width;
    g.font = `italic 900 ${26 * s}px Trebuchet MS, sans-serif`;
    const sw = g.measureText(suf).width;
    const px = mir ? x0 + w - 18 * s - pw - sw - 2 * s : x0 + 16 * s;
    g.font = `italic 900 ${64 * s}px Trebuchet MS, sans-serif`;
    this.outlined(g, pt, px, y0 + h - 10 * s, pcol);
    g.font = `italic 900 ${26 * s}px Trebuchet MS, sans-serif`;
    this.outlined(g, suf, px + pw + 2 * s, y0 + h - 22 * s, pcol);
    // item slot
    const bs = 70 * s, bx = mir ? x0 + 14 * s : x0 + w - bs - 14 * s, by = y0 + 14 * s;
    g.fillStyle = 'rgba(20,14,40,.7)'; g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 3;
    g.beginPath(); g.roundRect(bx, by, bs, bs, 14 * s); g.fill(); g.stroke();
    const icon = r.rollT > 0 ? ROLL_ICONS[Math.floor(this.t * 14) % ROLL_ICONS.length] : r.item ? ITEMS[r.item].icon : '';
    if (icon) { g.font = `${44 * s}px sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(icon, bx + bs / 2, by + bs / 2 + 3 * s); }
    if (r.shieldT > 0) {
      g.strokeStyle = '#7fd8ff'; g.lineWidth = 5 * s; g.beginPath();
      g.arc(bx + bs / 2, by + bs + 30 * s, 16 * s, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (r.shieldT / 8)); g.stroke();
      g.font = `${16 * s}px sans-serif`; g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('🛡️', bx + bs / 2, by + bs + 30 * s);
    }
    // TNT warning
    if (r.tnt > 0) {
      const pulse = 1 + (r.tnt < 3 ? Math.abs(Math.sin(this.t * 10)) * 0.15 : 0);
      g.textAlign = 'center'; g.textBaseline = 'middle';
      g.font = `italic 900 ${72 * s * pulse}px Trebuchet MS, sans-serif`;
      this.outlined(g, `🧨 ${Math.ceil(r.tnt)}`, x0 + w / 2, y0 + h * 0.3, '#ff3b3b');
      g.font = `900 ${18 * s}px Trebuchet MS, sans-serif`;
      this.outlined(g, 'BUMP SOMEONE TO PASS IT ON!', x0 + w / 2, y0 + h * 0.3 + 50 * s, '#fff');
      if (r.tnt < 3) { g.fillStyle = `rgba(255,40,40,${0.12 + Math.abs(Math.sin(this.t * 10)) * 0.15})`; g.fillRect(x0, y0, w, h); }
    }
    if (r.finalLapT > 0 && !r.finished) {
      g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = `italic 900 ${48 * s}px Trebuchet MS, sans-serif`;
      this.outlined(g, 'FINAL LAP!', x0 + w / 2, y0 + h * 0.42, '#ffcf3f');
    }
    if (r.spinT > 0 && r.tnt <= 0) { g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = `900 ${28 * s}px Trebuchet MS, sans-serif`; this.outlined(g, '💫 OOPS!', x0 + w / 2, y0 + h * 0.62, '#ffe36b'); }
    if (r.finished) {
      g.fillStyle = 'rgba(20,14,40,.45)'; g.fillRect(x0, y0, w, h);
      g.textAlign = 'center'; g.textBaseline = 'middle';
      g.font = `italic 900 ${60 * s}px Trebuchet MS, sans-serif`;
      this.outlined(g, `${ord(r.place)}!`, x0 + w / 2, y0 + h * 0.42, r.place === 1 ? '#ffcf3f' : '#fff');
      g.font = `800 ${22 * s}px Trebuchet MS, sans-serif`;
      this.outlined(g, `FINISHED  ${fmtTime(r.finishTime)}`, x0 + w / 2, y0 + h * 0.42 + 52 * s, '#fff');
    }
  }
  drawOverviewHUD(g, v) {
    // 4th quadrant when only 3 racers: standings + minimap
    g.fillStyle = 'rgba(20,14,40,.35)'; g.fillRect(v.x, v.y, v.w, v.h);
    const mm = Math.min(v.w * 0.5, v.h * 0.8);
    this.drawMinimap(g, v.x + v.w - mm - 20, v.y + (v.h - mm) / 2, mm, mm, false);
    const list = [...this.racers].sort((a, b) => a.pos - b.pos);
    let y = v.y + 30;
    g.textAlign = 'left'; g.textBaseline = 'middle';
    g.font = 'italic 900 26px Trebuchet MS, sans-serif'; g.fillStyle = '#ffcf3f'; g.fillText('STANDINGS', v.x + 24, y); y += 40;
    for (const r of list) {
      g.fillStyle = 'rgba(20,14,40,.75)'; g.beginPath(); g.roundRect(v.x + 20, y - 18, Math.min(300, v.w * 0.42), 36, 10); g.fill();
      g.fillStyle = '#fff'; g.font = '900 20px Trebuchet MS, sans-serif'; g.fillText(String(r.pos), v.x + 32, y);
      g.fillStyle = r.color; g.strokeStyle = '#ffffff'; g.lineWidth = 2; g.beginPath(); g.roundRect(v.x + 58, y - 9, 18, 18, 5); g.fill(); g.stroke();
      g.fillStyle = '#fff'; g.font = '700 18px Trebuchet MS, sans-serif'; g.fillText(r.name.slice(0, 14), v.x + 86, y);
      y += 44;
    }
  }
  drawMinimap(g, x, y, w, h, round) {
    const T = this.T;
    if (!this._mm) {
      let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
      for (let i = 0; i < T.N; i++) { minX = Math.min(minX, T.x[i]); maxX = Math.max(maxX, T.x[i]); minZ = Math.min(minZ, T.z[i]); maxZ = Math.max(maxZ, T.z[i]); }
      this._mm = { minX, maxX, minZ, maxZ };
    }
    const b = this._mm, pad = 14;
    const sc = Math.min((w - pad * 2) / (b.maxX - b.minX), (h - pad * 2) / (b.maxZ - b.minZ));
    const ox = x + (w - (b.maxX - b.minX) * sc) / 2, oy = y + (h - (b.maxZ - b.minZ) * sc) / 2;
    const P = (px, pz) => [ox + (px - b.minX) * sc, oy + (pz - b.minZ) * sc];
    g.fillStyle = 'rgba(20,14,40,.8)';
    g.beginPath(); if (round) g.arc(x + w / 2, y + h / 2, w / 2, 0, 7); else g.roundRect(x, y, w, h, 16); g.fill();
    g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 4; g.lineJoin = 'round'; g.beginPath();
    for (let i = 0; i < T.N; i += 4) { const p = P(T.x[i], T.z[i]); i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); }
    g.closePath(); g.stroke();
    const s0 = P(T.x[0], T.z[0]); g.fillStyle = '#fff'; g.fillRect(s0[0] - 4, s0[1] - 4, 8, 8);
    for (const r of [...this.racers].sort((a, b) => b.pos - a.pos)) {
      const p = P(r.x, r.z);
      g.fillStyle = r.color; g.strokeStyle = '#ffffff'; g.lineWidth = 2;
      g.beginPath(); g.arc(p[0], p[1], 6, 0, 7); g.fill(); g.stroke();
    }
  }
  outlined(g, text, x, y, color) {
    g.lineJoin = 'round'; g.lineWidth = Math.max(3, parseFloat(g.font.match(/(\d+(\.\d+)?)px/)[1]) / 7);
    g.strokeStyle = 'rgba(20,14,40,.9)'; g.strokeText(text, x, y);
    g.fillStyle = color; g.fillText(text, x, y);
  }
}
