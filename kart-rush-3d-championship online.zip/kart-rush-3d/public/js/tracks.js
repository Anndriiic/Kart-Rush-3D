// Track definitions + themed builder. Five Brunei-inspired tracks, picked at random each race.
// Each track: control points [x, z, y] in metres, a theme (surface, barriers, elevation) and a decor function.
import * as THREE from 'three';

export const HW = 7.5; // half-width of the racing surface (m)

export const TRACKS = [
  {
    id: 'water-village', name: 'Water Village Run', sub: 'Boardwalks over the river',
    control: [
      [-200, 140, 1.5], [0, 145, 1.5], [180, 140, 1.5], [260, 88, 1.5], [265, -8, 2.5], [212, -68, 3.5], [221, -133, 3.0],
      [140, -157, 2.0], [62, -124, 1.5], [42, -46, 1.5], [-32, 2, 1.5], [-96, -47, 2.5], [-88, -124, 4.5], [-168, -153, 3.0],
      [-248, -111, 1.5], [-260, 0, 1.5], [-256, 88, 1.5],
    ],
    startNear: [-60, 143], sky: '#8fd3ff', fog: '#bfe6ff',
    theme: { surface: 'planks', support: 'stilts', rail: 'rail', skirt: '#6b4426', arch: '#6b2fa0' },
    decor: decorWaterVillage,
  },
  {
    id: 'capital', name: 'Capital Circuit', sub: 'City streets past the golden dome',
    control: [
      [-215, 150, 0.3], [0, 150, 0.3], [200, 150, 0.3], [250, 130, 0.3], [262, 80, 0.3], [262, 0, 0.3], [240, -30, 0.3], [180, -42, 0.3],
      [125, -42, 0.3], [95, -72, 0.3], [95, -125, 0.3], [62, -160, 0.3], [0, -160, 0.3], [-62, -160, 0.3], [-95, -125, 0.3], [-95, -72, 0.3],
      [-125, -42, 0.3], [-200, -42, 0.3], [-250, -15, 0.3], [-265, 50, 0.3], [-258, 110, 0.3],
    ],
    startNear: [-60, 150], sky: '#9ad0ff', fog: '#cfe3f2',
    theme: { surface: 'asphalt', support: null, rail: 'wall', skirt: '#7b7f87', arch: '#c0392b' },
    decor: decorCapital,
  },
  {
    id: 'rainforest', name: 'Rainforest Rush', sub: 'Jungle trails and river crossings',
    control: [
      [-220, 160, 1], [-60, 170, 3], [60, 140, 7], [150, 170, 10], [250, 130, 12], [270, 40, 9], [200, -10, 5], [230, -90, 7],
      [160, -160, 11], [70, -140, 13], [25, -70, 9], [-25, -70, 9], [-70, -130, 6], [-150, -170, 8], [-250, -120, 10], [-270, -20, 6],
      [-205, 10, 3], [-200, 60, 2], [-250, 115, 1],
    ],
    startNear: [-140, 165], sky: '#a9d8c0', fog: '#9cc7a8', fogNear: 120, fogFar: 520,
    theme: { surface: 'dirt', support: 'earth', rail: 'log', skirt: '#6a4a2e', arch: '#2e7d32' },
    decor: decorRainforest,
  },
  {
    id: 'bridge', name: 'Bridge Sprint', sub: 'High above the bay',
    control: [
      [-300, 120, 9], [-100, 160, 11], [100, 150, 13], [280, 100, 11], [330, 0, 9], [280, -100, 11], [120, -140, 13], [0, -60, 10],
      [-120, -140, 13], [-280, -110, 11], [-340, 0, 9],
    ],
    startNear: [-200, 140], sky: '#7cc4f5', fog: '#b9def5', fogNear: 300, fogFar: 1100,
    theme: { surface: 'bridge', support: 'pillars', rail: 'steel', skirt: '#9aa0a8', arch: '#1f6fb2' },
    decor: decorBridge,
  },
  {
    id: 'beach', name: 'Beach Blast', sub: 'Sun, sand and palm trees',
    control: [
      [-280, 120, 0.4], [-150, 150, 0.4], [-30, 120, 0.6], [80, 160, 0.4], [220, 140, 0.4], [290, 60, 0.8], [250, -30, 1.2], [300, -110, 1.5],
      [200, -170, 2.2], [80, -120, 1.5], [-20, -170, 2.0], [-140, -130, 1.4], [-230, -160, 1.2], [-300, -60, 0.8], [-250, 30, 0.5],
    ],
    startNear: [-215, 135], sky: '#ffc88f', fog: '#ffdcb0', fogNear: 280, fogFar: 950,
    theme: { surface: 'sand', support: 'earth', rail: 'tyre', skirt: '#d9b878', arch: '#ff6f3c' },
    decor: decorBeach,
  },
];

// ---------- geometry helpers ----------
function catmull(ctrl, perSeg) {
  const out = [], n = ctrl.length;
  for (let i = 0; i < n; i++) {
    const p0 = ctrl[(i - 1 + n) % n], p1 = ctrl[i], p2 = ctrl[(i + 1) % n], p3 = ctrl[(i + 2) % n];
    for (let k = 0; k < perSeg; k++) {
      const t = k / perSeg, t2 = t * t, t3 = t2 * t;
      const f = (a, b, c, d) => 0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
      out.push([f(p0[0], p1[0], p2[0], p3[0]), f(p0[1], p1[1], p2[1], p3[1]), f(p0[2] || 0, p1[2] || 0, p2[2] || 0, p3[2] || 0)]);
    }
  }
  return out;
}

export function buildTrackData(def, spacing = 1.0) {
  const raw = catmull(def.control, 60);
  const pts = [raw[0]];
  let acc = 0;
  for (let i = 1; i <= raw.length; i++) {
    const a = raw[i - 1], b = raw[i % raw.length];
    let ax = a[0], az = a[1], ay = a[2];
    let seg = Math.hypot(b[0] - ax, b[1] - az);
    while (acc + seg >= spacing) {
      const t = (spacing - acc) / seg;
      ax += (b[0] - ax) * t; az += (b[1] - az) * t; ay += (b[2] - ay) * t;
      pts.push([ax, az, ay]);
      seg = Math.hypot(b[0] - ax, b[1] - az); acc = 0;
    }
    acc += seg;
  }
  if (Math.hypot(pts[pts.length - 1][0] - pts[0][0], pts[pts.length - 1][1] - pts[0][1]) < spacing * 0.5) pts.pop();
  let best = 0, bd = Infinity;
  pts.forEach((p, i) => { const d = Math.hypot(p[0] - def.startNear[0], p[1] - def.startNear[1]); if (d < bd) { bd = d; best = i; } });
  const P = pts.slice(best).concat(pts.slice(0, best));
  const N = P.length;
  const x = new Float32Array(N), z = new Float32Array(N), y = new Float32Array(N), tx = new Float32Array(N), tz = new Float32Array(N);
  for (let i = 0; i < N; i++) { x[i] = P[i][0]; z[i] = P[i][1]; y[i] = P[i][2]; }
  for (let i = 0; i < N; i++) {
    const a = (i - 3 + N) % N, b = (i + 3) % N;
    const dx = x[b] - x[a], dz = z[b] - z[a], l = Math.hypot(dx, dz) || 1;
    tx[i] = dx / l; tz[i] = dz / l;
  }
  const cell = 20, grid = new Map();
  for (let i = 0; i < N; i++) {
    const k = Math.floor(x[i] / cell) + ',' + Math.floor(z[i] / cell);
    if (!grid.has(k)) grid.set(k, []); grid.get(k).push(i);
  }
  const T = { def, N, x, z, y, tx, tz, spacing, length: N * spacing, grid, cell };
  T.wrap = (i) => ((i % N) + N) % N;
  T.nearest = (px, pz, hint) => {
    let bi = -1, bd = Infinity;
    if (hint != null && hint >= 0) {
      for (let k = -25; k <= 45; k++) {
        const i = T.wrap(hint + k), d = (x[i] - px) ** 2 + (z[i] - pz) ** 2;
        if (d < bd) { bd = d; bi = i; }
      }
      if (bd < 30 * 30) return { i: bi, d2: bd };
    }
    const cx = Math.floor(px / cell), cz = Math.floor(pz / cell);
    for (let r = 0; r <= 8; r++) {
      for (let gx = cx - r; gx <= cx + r; gx++) for (let gz = cz - r; gz <= cz + r; gz++) {
        if (Math.max(Math.abs(gx - cx), Math.abs(gz - cz)) !== r) continue;
        const l = grid.get(gx + ',' + gz); if (!l) continue;
        for (const i of l) { const d = (x[i] - px) ** 2 + (z[i] - pz) ** 2; if (d < bd) { bd = d; bi = i; } }
      }
      if (bi >= 0 && r >= 1 && Math.sqrt(bd) < r * cell) break;
    }
    if (bi < 0) for (let i = 0; i < N; i++) { const d = (x[i] - px) ** 2 + (z[i] - pz) ** 2; if (d < bd) { bd = d; bi = i; } }
    return { i: bi, d2: bd };
  };
  T.lateral = (px, pz, i) => (px - x[i]) * -tz[i] + (pz - z[i]) * tx[i];
  T.point = (i, lat = 0) => { i = T.wrap(i); return [x[i] + -tz[i] * lat, z[i] + tx[i] * lat, y[i]]; };
  T.minDistTo = (px, pz) => Math.sqrt(T.nearest(px, pz).d2);
  return T;
}

// ---------- textures ----------
function canvasTex(w, h, draw, repeat) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; }
  t.anisotropy = 4;
  return t;
}
function noise(g, w, h, n, alpha, light) {
  for (let i = 0; i < n; i++) { g.fillStyle = light ? `rgba(255,255,255,${Math.random() * alpha})` : `rgba(0,0,0,${Math.random() * alpha})`; g.fillRect(Math.random() * w, Math.random() * h, 2, 2); }
}
function kerbs(g, w, h, a, b, width = 16) {
  for (let i = 0; i < 4; i++) { g.fillStyle = i % 2 ? b : a; g.fillRect(0, i * h / 4, width, h / 4); g.fillRect(w - width, i * h / 4, width, h / 4); }
}
function surfaceTexture(kind) {
  return canvasTex(256, 256, (g, w, h) => {
    if (kind === 'planks') {
      g.fillStyle = '#9b6b43'; g.fillRect(0, 0, w, h);
      for (let i = 0; i < 8; i++) {
        const y = i * 32;
        g.fillStyle = `hsl(${24 + (i * 37) % 9}, ${38 + (i * 13) % 12}%, ${34 + (i * 23) % 10}%)`; g.fillRect(0, y + 1, w, 30);
        g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(0, y, w, 2);
        g.fillStyle = 'rgba(40,25,10,.6)'; for (const nx of [30, 226]) { g.beginPath(); g.arc(nx, y + 16, 2.2, 0, 7); g.fill(); }
      }
      kerbs(g, w, h, '#e63946', '#ffffff');
    } else if (kind === 'asphalt' || kind === 'bridge') {
      g.fillStyle = kind === 'bridge' ? '#5a5f68' : '#4a4e56'; g.fillRect(0, 0, w, h);
      noise(g, w, h, 2500, 0.25, false); noise(g, w, h, 1500, 0.12, true);
      g.fillStyle = '#f2f2f2'; g.fillRect(20, 0, 5, h); g.fillRect(w - 25, 0, 5, h);
      g.fillStyle = kind === 'bridge' ? '#ffcf3f' : '#f2f2f2'; g.fillRect(w / 2 - 3, 0, 6, h * 0.5);
      if (kind === 'asphalt') kerbs(g, w, h, '#e63946', '#ffffff', 14); else { g.fillStyle = '#ffcf3f'; g.fillRect(w / 2 + 6, 0, 6, h * 0.5); }
    } else if (kind === 'dirt') {
      g.fillStyle = '#8a5f3b'; g.fillRect(0, 0, w, h);
      noise(g, w, h, 3000, 0.25, false); noise(g, w, h, 1200, 0.15, true);
      g.fillStyle = 'rgba(60,35,15,.35)'; g.fillRect(70, 0, 22, h); g.fillRect(w - 92, 0, 22, h);
      g.fillStyle = '#4f8a2e'; g.fillRect(0, 0, 16, h); g.fillRect(w - 16, 0, 16, h);
      g.fillStyle = '#3d6f22'; for (let i = 0; i < 40; i++) { g.fillRect(14 + Math.random() * 6, Math.random() * h, 4, 6); g.fillRect(w - 20 + Math.random() * 6, Math.random() * h, 4, 6); }
    } else { // sand
      g.fillStyle = '#e3c58e'; g.fillRect(0, 0, w, h);
      noise(g, w, h, 2500, 0.12, false); noise(g, w, h, 1500, 0.2, true);
      g.strokeStyle = 'rgba(150,110,60,.25)'; g.lineWidth = 2;
      for (let i = 0; i < 12; i++) { g.beginPath(); g.moveTo(40, i * 22); g.quadraticCurveTo(w / 2, i * 22 + 8, w - 40, i * 22); g.stroke(); }
      kerbs(g, w, h, '#1f8fd6', '#ffffff');
    }
  }, true);
}
function stripeTexture(a, b, n = 2) {
  return canvasTex(64, 16, (g, w, h) => { for (let i = 0; i < n; i++) { g.fillStyle = i % 2 ? b : a; g.fillRect(i * w / n, 0, w / n, h); } }, true);
}
function checkerTexture() {
  return canvasTex(128, 32, (g) => { for (let r = 0; r < 2; r++) for (let k = 0; k < 8; k++) { g.fillStyle = (r + k) % 2 ? '#111' : '#fff'; g.fillRect(k * 16, r * 16, 16, 16); } });
}
function waterTexture(base = '#2a9fb0') {
  return canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = base; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 260; i++) {
      g.strokeStyle = `rgba(255,255,255,${0.05 + Math.random() * 0.12})`; g.lineWidth = 1 + Math.random() * 1.5;
      const x = Math.random() * w, y = Math.random() * h, l = 6 + Math.random() * 18;
      g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + l / 2, y - 2, x + l, y); g.stroke();
    }
  }, true);
}
function windowTexture(wall) {
  return canvasTex(64, 128, (g, w, h) => {
    g.fillStyle = wall; g.fillRect(0, 0, w, h);
    for (let r = 0; r < 8; r++) for (let c = 0; c < 4; c++) { g.fillStyle = Math.random() < 0.25 ? '#ffe9a8' : 'rgba(30,50,80,.75)'; g.fillRect(4 + c * 15, 6 + r * 15, 10, 10); }
  }, true);
}
export function textTexture(text, opts = {}) {
  const { w = 1024, h = 160, bg = '#ffcf3f', fg = '#1b1430', font = 'italic 900 110px Trebuchet MS, sans-serif' } = opts;
  return canvasTex(w, h, (g) => { g.fillStyle = bg; g.fillRect(0, 0, w, h); g.fillStyle = fg; g.font = font; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, w / 2, h / 2 + 6); });
}

const M = (color, o = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.75, metalness: 0.05, ...o });
function rng(seed) { return () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }; }

// ---------- builder ----------
export function buildTrackScene(T) {
  const group = new THREE.Group();
  const def = T.def, th = def.theme;
  const { N, x, z, y, tx, tz } = T;
  const maxY = y.reduce((a, b) => Math.max(a, b), 0);

  // racing surface ribbon
  const pos = new Float32Array((N + 1) * 2 * 3), uv = new Float32Array((N + 1) * 2 * 2), idx = [];
  for (let k = 0; k <= N; k++) {
    const i = k % N, rx = -tz[i], rz = tx[i];
    pos.set([x[i] - rx * HW, y[i], z[i] - rz * HW, x[i] + rx * HW, y[i], z[i] + rz * HW], k * 6);
    const v = k * T.spacing / 6; uv.set([0, v, 1, v], k * 4);
    if (k < N) { const a = k * 2; idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3); }
  }
  const sg = new THREE.BufferGeometry();
  sg.setAttribute('position', new THREE.BufferAttribute(pos, 3)); sg.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  sg.setIndex(idx); sg.computeVertexNormals();
  group.add(new THREE.Mesh(sg, new THREE.MeshStandardMaterial({ map: surfaceTexture(th.surface), roughness: 0.85, side: THREE.DoubleSide })));

  // vertical strips along both edges (skirts, barriers)
  function sideStrip(sign, top, bottom, mat, offset = HW, absBottom = false, uvScale = 0) {
    const p = new Float32Array((N + 1) * 2 * 3), u = new Float32Array((N + 1) * 2 * 2), ix = [];
    for (let k = 0; k <= N; k++) {
      const i = k % N, rx = -tz[i] * sign, rz = tx[i] * sign;
      p.set([x[i] + rx * offset, y[i] + top, z[i] + rz * offset, x[i] + rx * offset, absBottom ? bottom : y[i] + bottom, z[i] + rz * offset], k * 6);
      const v = uvScale ? k * T.spacing / uvScale : 0; u.set([v, 1, v, 0], k * 4);
      if (k < N) { const a = k * 2; ix.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(p, 3)); g.setAttribute('uv', new THREE.BufferAttribute(u, 2));
    g.setIndex(ix); g.computeVertexNormals();
    return new THREE.Mesh(g, mat);
  }
  const skirtM = M(th.skirt, { side: THREE.DoubleSide });
  const skirtBottom = th.support === 'stilts' ? -maxY - 1 : th.support === 'pillars' ? -0.9 : -3;
  for (const sg2 of [-1, 1]) group.add(sideStrip(sg2, 0, skirtBottom, skirtM, HW));
  if (th.support === 'earth') for (const sg2 of [-1, 1]) group.add(sideStrip(sg2, -0.02, -4, skirtM, HW + 0.02, true));

  // barriers
  const D = THREE.DoubleSide;
  if (th.rail === 'rail') {
    for (const s of [-1, 1]) { group.add(sideStrip(s, 1.1, 0.75, M('#f4f1e8', { side: D }), HW + 0.25)); group.add(sideStrip(s, 0.45, 0.25, M('#e63946', { side: D }), HW + 0.25)); }
  } else if (th.rail === 'wall') {
    const st = stripeTexture('#e63946', '#ffffff'); const wm = new THREE.MeshStandardMaterial({ map: st, side: D, roughness: 0.7 });
    for (const s of [-1, 1]) { group.add(sideStrip(s, 1.0, 0, M('#c9ccd2', { side: D }), HW + 0.35)); group.add(sideStrip(s, 1.25, 1.0, wm, HW + 0.35, false, 4)); }
  } else if (th.rail === 'log') {
    for (const s of [-1, 1]) { group.add(sideStrip(s, 0.9, 0.55, M('#7a5230', { side: D }), HW + 0.3)); group.add(sideStrip(s, 0.4, 0.1, M('#6a4426', { side: D }), HW + 0.3)); }
  } else if (th.rail === 'steel') {
    for (const s of [-1, 1]) { group.add(sideStrip(s, 1.2, 1.05, M('#d9dde3', { side: D, metalness: 0.5, roughness: 0.3 }), HW + 0.3)); group.add(sideStrip(s, 0.7, 0.55, M('#d9dde3', { side: D, metalness: 0.5, roughness: 0.3 }), HW + 0.3)); group.add(sideStrip(s, 0.35, 0, M('#1f6fb2', { side: D }), HW + 0.3)); }
  } else if (th.rail === 'tyre') {
    const st = stripeTexture('#ff6f3c', '#f4f4f4'); const tm = new THREE.MeshStandardMaterial({ map: st, side: D, roughness: 0.8 });
    for (const s of [-1, 1]) group.add(sideStrip(s, 0.8, 0, tm, HW + 0.35, false, 2.4));
  }

  // posts / stilts / pillars (instanced)
  const q = new THREE.Quaternion(), s3 = new THREE.Vector3(), p3 = new THREE.Vector3(), m4 = new THREE.Matrix4();
  if (th.rail === 'rail' || th.rail === 'log' || th.rail === 'steel') {
    const step = th.rail === 'steel' ? 6 : 4;
    const posts = new THREE.InstancedMesh(new THREE.BoxGeometry(0.22, 1.2, 0.22), M(th.rail === 'log' ? '#5a3a20' : th.rail === 'steel' ? '#aab1ba' : '#f4f1e8'), Math.ceil(N / step) * 2);
    let n = 0;
    for (let i = 0; i < N; i += step) for (const sign of [-1, 1]) { const rx = -tz[i] * sign, rz = tx[i] * sign; p3.set(x[i] + rx * (HW + 0.3), y[i] + 0.55, z[i] + rz * (HW + 0.3)); s3.set(1, 1, 1); m4.compose(p3, q, s3); posts.setMatrixAt(n++, m4); }
    posts.count = n; group.add(posts);
  }
  if (th.support === 'stilts') {
    const st = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.22, 0.22, 1, 6), M('#5a3a20'), Math.ceil(N / 8) * 2);
    let n = 0;
    for (let i = 0; i < N; i += 8) for (const sign of [-1, 1]) { const rx = -tz[i] * sign, rz = tx[i] * sign, h = y[i] + 3; p3.set(x[i] + rx * (HW - 0.4), y[i] - h / 2, z[i] + rz * (HW - 0.4)); s3.set(1, h, 1); m4.compose(p3, q, s3); st.setMatrixAt(n++, m4); }
    st.count = n; group.add(st);
  } else if (th.support === 'pillars') {
    const pl = new THREE.InstancedMesh(new THREE.BoxGeometry(2.2, 1, 2.2), M('#b8bcc4'), Math.ceil(N / 40) + 2);
    const cap = new THREE.InstancedMesh(new THREE.BoxGeometry(HW * 2 + 1, 0.8, 2.6), M('#a2a7b0'), Math.ceil(N / 40) + 2);
    let n = 0;
    for (let i = 0; i < N; i += 40) {
      const h = y[i] + 4; const a = Math.atan2(tx[i], tz[i]); q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), a);
      p3.set(x[i], y[i] - h / 2 - 0.9, z[i]); s3.set(1, h, 1); m4.compose(p3, q, s3); pl.setMatrixAt(n, m4);
      p3.set(x[i], y[i] - 1.2, z[i]); s3.set(1, 1, 1); m4.compose(p3, q, s3); cap.setMatrixAt(n, m4); n++;
    }
    q.identity(); pl.count = cap.count = n; group.add(pl, cap);
  }

  // start line + arch
  {
    const i = 0, a = Math.atan2(tx[i], tz[i]);
    const line = new THREE.Mesh(new THREE.PlaneGeometry(HW * 2, 2), new THREE.MeshBasicMaterial({ map: checkerTexture() }));
    line.rotation.x = -Math.PI / 2; line.rotation.z = a; line.position.set(x[i], y[i] + 0.02, z[i]); group.add(line);
    const arch = new THREE.Group();
    for (const sign of [-1, 1]) { const pil = new THREE.Mesh(new THREE.BoxGeometry(0.9, 8, 0.9), M(th.arch)); pil.position.set(sign * (HW + 1.2), 4, 0); arch.add(pil); }
    const tt = textTexture('KART RUSH');
    const ban = new THREE.Mesh(new THREE.BoxGeometry(HW * 2 + 3.3, 2.2, 0.4), [M(th.arch), M(th.arch), M(th.arch), M(th.arch), new THREE.MeshBasicMaterial({ map: tt }), new THREE.MeshBasicMaterial({ map: tt })]);
    ban.position.y = 8; arch.add(ban);
    arch.position.set(x[i], y[i], z[i]); arch.rotation.y = a; group.add(arch);
  }

  const boxRows = [0.18, 0.43, 0.68, 0.88].map(f => Math.round(N * f));
  def.decor(group, T);
  return { group, boxRows, water: group.userData.water };
}

// ---------- shared decor pieces ----------
function scatter(T, R, count, { minD, maxD, w = 700, h = 460, spacing = 10, tries = 4000, extra = null }) {
  const out = [];
  for (let t = 0; t < tries && out.length < count; t++) {
    const px = (R() - 0.5) * w, pz = (R() - 0.5) * h;
    const d = T.minDistTo(px, pz);
    if (d < minD || d > maxD) continue;
    if (extra && !extra(px, pz)) continue;
    if (out.some(s => (s[0] - px) ** 2 + (s[1] - pz) ** 2 < spacing * spacing)) continue;
    out.push([px, pz, R()]);
  }
  return out;
}
function groundPlane(group, color, y = -0.05, size = 2400) {
  const g = new THREE.Mesh(new THREE.PlaneGeometry(size, size), M(color, { roughness: 0.95 }));
  g.rotation.x = -Math.PI / 2; g.position.y = y; group.add(g); return g;
}
function waterPlane(group, base, y = -0.6, size = 2400, repeat = 60) {
  const wt = waterTexture(base); wt.repeat.set(repeat, repeat);
  const w = new THREE.Mesh(new THREE.PlaneGeometry(size, size), new THREE.MeshStandardMaterial({ color: '#ffffff', map: wt, roughness: 0.25, metalness: 0.1 }));
  w.rotation.x = -Math.PI / 2; w.position.y = y; group.add(w);
  group.userData.water = wt; return w;
}
function hillsRing(group, R, color, r0 = 620, n = 26, hmin = 40, hmax = 110) {
  const hillMat = M(color, { flatShading: true });
  for (let k = 0; k < n; k++) {
    const a = (k / n) * Math.PI * 2, r = r0 + R() * 120;
    const h = new THREE.Mesh(new THREE.ConeGeometry(70 + R() * 80, hmin + R() * (hmax - hmin), 7), hillMat);
    h.position.set(Math.cos(a) * r, 0, Math.sin(a) * r); group.add(h);
  }
}
function palms(group, spots, withSand = false) {
  if (!spots.length) return;
  const trunkG = new THREE.CylinderGeometry(0.25, 0.4, 8, 6), leafG = new THREE.ConeGeometry(0.9, 5, 3);
  const trunks = new THREE.InstancedMesh(trunkG, M('#8d6e4a'), spots.length);
  const leaves = new THREE.InstancedMesh(leafG, M('#2e9e4f', { flatShading: true, side: THREE.DoubleSide }), spots.length * 6);
  const sand = withSand ? new THREE.InstancedMesh(new THREE.CylinderGeometry(4, 5, 1, 10), M('#e8d29a'), spots.length) : null;
  const m4 = new THREE.Matrix4(), o = new THREE.Object3D();
  spots.forEach(([px, pz, r], i) => {
    o.position.set(px, 4, pz); o.rotation.set(0, 0, (r - 0.5) * 0.3); o.scale.set(1, 1, 1); o.updateMatrix(); trunks.setMatrixAt(i, o.matrix);
    for (let l = 0; l < 6; l++) {
      o.position.set(px, 8, pz); o.rotation.set(Math.PI / 2.6, l * Math.PI / 3 + r, 0); o.updateMatrix();
      m4.makeTranslation(0, 2.2, 0); o.matrix.multiply(m4); leaves.setMatrixAt(i * 6 + l, o.matrix);
    }
    if (sand) { o.position.set(px, -0.4, pz); o.rotation.set(0, 0, 0); o.updateMatrix(); sand.setMatrixAt(i, o.matrix); }
  });
  group.add(trunks, leaves); if (sand) group.add(sand);
}
function mosque(group, px, pz, scale = 1, withIsland = true) {
  const mq = new THREE.Group();
  if (withIsland) {
    const isle = new THREE.Mesh(new THREE.CylinderGeometry(40, 44, 2, 24), M('#d9c79b')); isle.position.y = -0.3; mq.add(isle);
    const lawn = new THREE.Mesh(new THREE.CylinderGeometry(36, 36, 0.4, 24), M('#5cb85c')); lawn.position.y = 0.8; mq.add(lawn);
  }
  const base = new THREE.Mesh(new THREE.BoxGeometry(26, 12, 26), M('#f7f4ee')); base.position.y = 7; mq.add(base);
  const drum = new THREE.Mesh(new THREE.CylinderGeometry(8, 8, 4, 20), M('#f7f4ee')); drum.position.y = 15; mq.add(drum);
  const gold = M('#f2c14e', { metalness: 0.8, roughness: 0.25 });
  const dome = new THREE.Mesh(new THREE.SphereGeometry(8.5, 24, 14, 0, Math.PI * 2, 0, Math.PI / 1.7), gold); dome.position.y = 16.5; dome.scale.y = 1.25; mq.add(dome);
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.6, 4, 8), gold); tip.position.y = 29; mq.add(tip);
  for (const [ox, oz] of [[-15, -15], [15, -15], [-15, 15], [15, 15]]) {
    const mn = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.5, 26, 10), M('#f7f4ee')); mn.position.set(ox, 13, oz); mq.add(mn);
    const md = new THREE.Mesh(new THREE.SphereGeometry(1.8, 12, 8), gold); md.position.set(ox, 27, oz); mq.add(md);
  }
  mq.position.set(px, 0, pz); mq.scale.setScalar(scale); group.add(mq);
}
function boats(group, T, R, n, area = [700, 480], minD = HW + 6) {
  const g = new THREE.Group();
  for (let k = 0; k < n; k++) {
    let px, pz, tries = 0;
    do { px = (R() - 0.5) * area[0]; pz = (R() - 0.5) * area[1]; tries++; } while (T.minDistTo(px, pz) < minD && tries < 50);
    const b = new THREE.Group();
    b.add(new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.6, 6), M(['#e63946', '#2f7ff5', '#ffd23f', '#2cbf55'][k % 4])));
    const canopy = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.12, 2.4), M('#ffffff')); canopy.position.set(0, 1.3, -0.5); b.add(canopy);
    b.position.set(px, -0.35, pz); b.rotation.y = R() * 6; b.userData.phase = R() * 6; g.add(b);
  }
  group.add(g); group.userData.boats = g;
}

// ---------- 1. Water Village ----------
function decorWaterVillage(group, T) {
  const R = rng(11);
  waterPlane(group, '#2a9fb0');
  hillsRing(group, R, '#3f8f4a');
  const spots = scatter(T, R, 150, { minD: HW + 9, maxD: 70, w: 640, h: 420, spacing: 15, tries: 1400 });
  const wallCols = ['#f6d6a8', '#a8d8ea', '#f7b2bd', '#c5e3a5', '#fff1b6', '#d8c4f0', '#ffffff'], roofCols = ['#c0392b', '#2e86ab', '#1f7a4c', '#8e44ad', '#d35400'];
  const walls = new THREE.InstancedMesh(new THREE.BoxGeometry(8, 4, 6), M('#ffffff'), spots.length);
  const roofs = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.01, 5.6, 3, 4, 1), M('#ffffff', { flatShading: true }), spots.length);
  const stl = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.25, 0.25, 4, 5), M('#5a3a20'), spots.length * 4);
  const deck = new THREE.InstancedMesh(new THREE.BoxGeometry(10, 0.3, 8), M('#8a5a34'), spots.length);
  const o = new THREE.Object3D(), col = new THREE.Color();
  spots.forEach(([px, pz, r], i) => {
    const rot = r * Math.PI;
    o.position.set(px, 3.4, pz); o.rotation.set(0, rot, 0); o.scale.set(1, 1, 1); o.updateMatrix(); walls.setMatrixAt(i, o.matrix); walls.setColorAt(i, col.set(wallCols[i % wallCols.length]));
    o.position.set(px, 6.9, pz); o.rotation.set(0, rot + Math.PI / 4, 0); o.scale.set(1.15, 1, 0.9); o.updateMatrix(); roofs.setMatrixAt(i, o.matrix); roofs.setColorAt(i, col.set(roofCols[i % roofCols.length]));
    o.position.set(px, 1.25, pz); o.rotation.set(0, rot, 0); o.scale.set(1, 1, 1); o.updateMatrix(); deck.setMatrixAt(i, o.matrix);
    let k = 0; const c = Math.cos(rot), sn = Math.sin(rot);
    for (const [ox, oz] of [[-3.5, -2.5], [3.5, -2.5], [-3.5, 2.5], [3.5, 2.5]]) { o.position.set(px + ox * c + oz * sn, -0.6, pz - ox * sn + oz * c); o.updateMatrix(); stl.setMatrixAt(i * 4 + k++, o.matrix); }
  });
  group.add(walls, roofs, stl, deck);
  boats(group, T, R, 24);
  if (T.minDistTo(150, 30) > 45) mosque(group, 150, 30); else mosque(group, -150, 40);
  palms(group, scatter(T, R, 40, { minD: HW + 6, maxD: 60, w: 680, h: 460, spacing: 8 }), true);
}

// ---------- 2. Capital Circuit ----------
function decorCapital(group, T) {
  const R = rng(23);
  groundPlane(group, '#7fae5b');
  // pavements along the track
  const pave = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), M('#c9c4b8'));
  // river/waterfront to the south
  const river = waterPlane(group, '#2f8fb5', -0.02, 2400, 60); river.position.z = -1440; // plane edge at z≈-240
  // lagoon with the golden-domed mosque inside the loop
  const lag = new THREE.Mesh(new THREE.CircleGeometry(55, 40), new THREE.MeshStandardMaterial({ color: '#3fa6c9', roughness: 0.2 }));
  lag.rotation.x = -Math.PI / 2; lag.position.set(170, 0.02, 50); group.add(lag);
  mosque(group, 170, 50, 1.15, true);
  // city blocks: towers with window textures
  const spots = scatter(T, R, 120, { minD: HW + 16, maxD: 220, w: 900, h: 640, spacing: 26, extra: (px, pz) => Math.hypot(px - 170, pz - 50) > 75 && pz > -230 });
  const cols = ['#d8d2c4', '#b9c6d3', '#e8dccb', '#c7b8a8', '#a9b6c4', '#f0ece4'];
  const byCol = cols.map(() => []);
  spots.forEach((s, i) => byCol[i % cols.length].push(s));
  const o = new THREE.Object3D();
  byCol.forEach((list, ci) => {
    if (!list.length) return;
    const tex = windowTexture(cols[ci]); tex.repeat.set(2, 3);
    const mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.7 }), list.length);
    const roofM = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), M('#6f747c'), list.length);
    list.forEach(([px, pz, r], i) => {
      const d = T.minDistTo(px, pz), h = 10 + r * 25 + Math.min(40, d * 0.25), w = 14 + r * 10;
      o.position.set(px, h / 2, pz); o.rotation.set(0, r * 0.4, 0); o.scale.set(w, h, w * 0.8); o.updateMatrix(); mesh.setMatrixAt(i, o.matrix);
      o.position.set(px, h + 0.5, pz); o.scale.set(w * 0.9, 1, w * 0.7); o.updateMatrix(); roofM.setMatrixAt(i, o.matrix);
    });
    group.add(mesh, roofM);
  });
  // pavement strips + street lamps + palms along the track
  const lampN = Math.ceil(T.N / 30) * 2, lamps = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.15, 0.2, 7, 6), M('#3a3f47'), lampN);
  const heads = new THREE.InstancedMesh(new THREE.SphereGeometry(0.5, 8, 6), new THREE.MeshStandardMaterial({ color: '#fff3c4', emissive: '#ffe08a', emissiveIntensity: 0.8 }), lampN);
  let n = 0; const pp = [];
  for (let i = 0; i < T.N; i += 30) for (const sg of [-1, 1]) {
    const p = T.point(i, sg * (HW + 3));
    o.position.set(p[0], 3.5, p[1]); o.rotation.set(0, 0, 0); o.scale.set(1, 1, 1); o.updateMatrix(); lamps.setMatrixAt(n, o.matrix);
    o.position.set(p[0], 7.2, p[1]); o.updateMatrix(); heads.setMatrixAt(n++, o.matrix);
    if ((i / 30) % 2 === 0) { const q2 = T.point(i + 15, sg * (HW + 5)); pp.push([q2[0], q2[1], R()]); }
  }
  lamps.count = heads.count = n; group.add(lamps, heads);
  const sidewalk = new THREE.Mesh(new THREE.RingGeometry(0, 0, 3), M('#c9c4b8'));
  palms(group, pp.filter(p => T.minDistTo(p[0], p[1]) > HW + 3));
  // flags / bunting poles near the start
  for (let k = 0; k < 6; k++) {
    const p = T.point(-20 - k * 12, -(HW + 6));
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 9, 6), M('#dddddd')); pole.position.set(p[0], 4.5, p[1]); group.add(pole);
    const fl = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.4), M(['#f7e017', '#ffffff', '#ef3b4a', '#2f7ff5'][k % 4], { side: THREE.DoubleSide })); fl.position.set(p[0] + 1.2, 8, p[1]); group.add(fl);
  }
  hillsRing(group, R, '#5f8f5a', 760, 20, 30, 80);
  void pave; void sidewalk;
}

// ---------- 3. Rainforest Rush ----------
function decorRainforest(group, T) {
  const R = rng(37);
  groundPlane(group, '#3f6f2f', -0.3);
  // river running north-south under the crossing
  const rv = waterTexture('#3d8c86'); rv.repeat.set(2, 30);
  const river = new THREE.Mesh(new THREE.PlaneGeometry(36, 400), new THREE.MeshStandardMaterial({ map: rv, roughness: 0.25 }));
  river.rotation.x = -Math.PI / 2; river.position.set(0, -0.2, -110); group.add(river);
  group.userData.water = rv;
  // dense trees (trunks + layered canopy)
  const trees = scatter(T, R, 420, { minD: HW + 4, maxD: 140, w: 760, h: 520, spacing: 7, tries: 9000, extra: (px) => Math.abs(px) > 22 });
  const trunk = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.5, 0.8, 1, 6), M('#5b3f28'), trees.length);
  const c1 = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 0), M('#2f7d32', { flatShading: true }), trees.length);
  const c2 = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 0), M('#3d9440', { flatShading: true }), trees.length);
  const o = new THREE.Object3D(), col = new THREE.Color();
  trees.forEach(([px, pz, r], i) => {
    const h = 10 + r * 16, cs = 4 + r * 4;
    o.position.set(px, h / 2 - 0.3, pz); o.rotation.set(0, 0, 0); o.scale.set(1, h, 1); o.updateMatrix(); trunk.setMatrixAt(i, o.matrix);
    o.position.set(px, h, pz); o.rotation.set(0, r * 6, 0); o.scale.set(cs, cs * 0.8, cs); o.updateMatrix(); c1.setMatrixAt(i, o.matrix); c1.setColorAt(i, col.setHSL(0.3 + r * 0.06, 0.5, 0.3 + r * 0.08));
    o.position.set(px + 1.5, h + cs * 0.6, pz - 1); o.scale.set(cs * 0.7, cs * 0.6, cs * 0.7); o.updateMatrix(); c2.setMatrixAt(i, o.matrix);
  });
  group.add(trunk, c1, c2);
  // ferns along the trail
  const fernSpots = scatter(T, R, 260, { minD: HW + 1.5, maxD: HW + 10, w: 760, h: 520, spacing: 3, tries: 8000 });
  const ferns = new THREE.InstancedMesh(new THREE.ConeGeometry(1.2, 2.2, 5), M('#4caf50', { flatShading: true }), fernSpots.length);
  fernSpots.forEach(([px, pz, r], i) => { const nn = T.nearest(px, pz); o.position.set(px, T.y[nn.i] + 0.4, pz); o.rotation.set(0, r * 6, 0); o.scale.set(1, 0.8 + r * 0.6, 1); o.updateMatrix(); ferns.setMatrixAt(i, o.matrix); });
  group.add(ferns);
  // mossy rocks
  const rocks = scatter(T, R, 60, { minD: HW + 6, maxD: 60, w: 760, h: 520, spacing: 10 });
  const rk = new THREE.InstancedMesh(new THREE.DodecahedronGeometry(1, 0), M('#7c8a72', { flatShading: true }), rocks.length);
  rocks.forEach(([px, pz, r], i) => { o.position.set(px, 0.3, pz); o.rotation.set(r * 3, r * 5, 0); const s = 1.5 + r * 3; o.scale.set(s, s * 0.7, s); o.updateMatrix(); rk.setMatrixAt(i, o.matrix); });
  group.add(rk);
  // waterfall on a cliff at the river's north end
  const cliff = new THREE.Mesh(new THREE.BoxGeometry(70, 40, 20), M('#6d7563', { flatShading: true })); cliff.position.set(0, 20, 100); group.add(cliff);
  const fall = new THREE.Mesh(new THREE.PlaneGeometry(14, 40), new THREE.MeshStandardMaterial({ color: '#d9f3ff', transparent: true, opacity: 0.85, emissive: '#bfe9ff', emissiveIntensity: 0.4 }));
  fall.position.set(0, 20, 89.8); group.add(fall);
  // longhouse near the start
  const lh = new THREE.Group();
  const hb = new THREE.Mesh(new THREE.BoxGeometry(40, 5, 9), M('#9c6b3f')); hb.position.y = 5.5; lh.add(hb);
  const roof = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 7.5, 40, 3, 1), M('#5a3d22', { flatShading: true })); roof.rotation.z = Math.PI / 2; roof.position.y = 9.6; roof.scale.set(1, 1, 0.75); lh.add(roof);
  for (let k = -18; k <= 18; k += 6) for (const sz of [-4, 4]) { const st = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 3.2, 5), M('#5a3a20')); st.position.set(k, 1.6, sz); lh.add(st); }
  lh.position.set(-120, 0, 205); group.add(lh);
  hillsRing(group, R, '#2e6b35', 560, 28, 60, 140);
}

// ---------- 4. Bridge Sprint ----------
function decorBridge(group, T) {
  const R = rng(51);
  waterPlane(group, '#1f7fb8', -0.6, 3000, 70);
  // islands
  for (let k = 0; k < 9; k++) {
    let px, pz, tries = 0;
    do { px = (R() - 0.5) * 900; pz = (R() - 0.5) * 700; tries++; } while (T.minDistTo(px, pz) < 60 && tries < 80);
    const isl = new THREE.Group();
    const sand = new THREE.Mesh(new THREE.CylinderGeometry(22 + R() * 15, 28 + R() * 15, 2, 14), M('#e2cf98')); sand.position.y = -0.5; isl.add(sand);
    const hill = new THREE.Mesh(new THREE.ConeGeometry(18 + R() * 12, 14 + R() * 18, 8), M('#4a9a4f', { flatShading: true })); hill.position.y = 6; isl.add(hill);
    isl.position.set(px, 0, pz); group.add(isl);
  }
  // cable-stayed towers at a few points
  const towerM = M('#e8ebef'), cableM = new THREE.LineBasicMaterial({ color: '#f4f6f8' });
  for (const f of [0.08, 0.32, 0.58, 0.82]) {
    const i = Math.round(T.N * f), y0 = T.y[i];
    const a = Math.atan2(T.tx[i], T.tz[i]);
    const tw = new THREE.Group();
    for (const s of [-1, 1]) { const leg = new THREE.Mesh(new THREE.BoxGeometry(1.4, 46, 1.4), towerM); leg.position.set(s * (HW + 2), 23 - 6, 0); leg.rotation.z = -s * 0.06; tw.add(leg); }
    const beam = new THREE.Mesh(new THREE.BoxGeometry(HW * 2 + 6, 1.4, 1.6), towerM); beam.position.y = 34; tw.add(beam);
    tw.position.set(T.x[i], y0, T.z[i]); tw.rotation.y = a; group.add(tw);
    const pts = [];
    for (const s of [-1, 1]) for (const d of [-60, -45, -30, -15, 15, 30, 45, 60]) {
      const j = T.wrap(i + d), p = T.point(j, s * (HW + 0.4));
      const top = new THREE.Vector3(T.x[i] + -T.tz[i] * s * (HW + 1), y0 + 38, T.z[i] + T.tx[i] * s * (HW + 1));
      pts.push(top, new THREE.Vector3(p[0], p[2] + 1.2, p[1]));
    }
    group.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(pts), cableM));
  }
  // lamp posts along the deck
  const n0 = Math.ceil(T.N / 25) * 2, lamps = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.12, 0.15, 6, 6), M('#c8ccd2'), n0);
  const heads = new THREE.InstancedMesh(new THREE.BoxGeometry(1.4, 0.3, 0.5), new THREE.MeshStandardMaterial({ color: '#fff3c4', emissive: '#ffe08a', emissiveIntensity: 0.6 }), n0);
  const o = new THREE.Object3D(); let n = 0;
  for (let i = 0; i < T.N; i += 25) for (const sg of [-1, 1]) {
    const p = T.point(i, sg * (HW + 0.9));
    o.position.set(p[0], p[2] + 3, p[1]); o.rotation.set(0, 0, 0); o.updateMatrix(); lamps.setMatrixAt(n, o.matrix);
    o.position.set(p[0] - T.tz[i] * -sg * 0.6, p[2] + 6, p[1] + T.tx[i] * -sg * 0.6); o.rotation.set(0, Math.atan2(T.tx[i], T.tz[i]), 0); o.updateMatrix(); heads.setMatrixAt(n++, o.matrix);
  }
  lamps.count = heads.count = n; group.add(lamps, heads);
  // distant skyline + hills
  const sky = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), M('#9aa6b5'), 40);
  for (let k = 0; k < 40; k++) { const a = -0.6 + (k / 40) * 1.2, r = 700 + R() * 60, h = 20 + R() * 70; o.position.set(Math.cos(a + Math.PI / 2) * r, h / 2, Math.sin(a + Math.PI / 2) * r); o.rotation.set(0, R(), 0); o.scale.set(18 + R() * 14, h, 18); o.updateMatrix(); sky.setMatrixAt(k, o.matrix); }
  group.add(sky);
  hillsRing(group, R, '#4f8d58', 900, 30, 50, 140);
  boats(group, T, R, 30, [900, 700], 25);
  // sailing boats
  for (let k = 0; k < 8; k++) {
    const b = new THREE.Group();
    b.add(new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.8, 8), M('#ffffff')));
    const sail = new THREE.Mesh(new THREE.ConeGeometry(3, 9, 3), M(['#ff6f3c', '#ffd23f', '#2f7ff5', '#ffffff'][k % 4], { flatShading: true })); sail.position.y = 5; b.add(sail);
    let px, pz, tries = 0; do { px = (R() - 0.5) * 900; pz = (R() - 0.5) * 700; tries++; } while (T.minDistTo(px, pz) < 30 && tries < 50);
    b.position.set(px, -0.2, pz); b.rotation.y = R() * 6; b.userData.phase = R() * 6; group.userData.boats.add(b);
  }
}

// ---------- 5. Beach Blast ----------
function decorBeach(group, T) {
  const R = rng(77);
  groundPlane(group, '#e8cf98', -0.1);
  // sea on the north side (z > 205) with a foam line
  const sea = waterPlane(group, '#2aa5c7', -0.05, 3000, 70); sea.position.z = 205 + 1500;
  const foam = new THREE.Mesh(new THREE.PlaneGeometry(3000, 4), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.7 })); foam.rotation.x = -Math.PI / 2; foam.position.set(0, 0.0, 205); group.add(foam);
  group.userData.foam = foam;
  // grassy dunes inland
  const dunes = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 10, 6), M('#a7c66b', { flatShading: true }), 40);
  const o = new THREE.Object3D(); let n = 0;
  for (const [px, pz, r] of scatter(T, R, 40, { minD: 30, maxD: 200, w: 900, h: 600, spacing: 30, extra: (px, pz) => pz < 140 })) { o.position.set(px, -4, pz); o.scale.set(14 + r * 18, 7 + r * 5, 12 + r * 14); o.rotation.set(0, r * 3, 0); o.updateMatrix(); dunes.setMatrixAt(n++, o.matrix); }
  dunes.count = n; group.add(dunes);
  // lots of palms
  palms(group, scatter(T, R, 110, { minD: HW + 5, maxD: 90, w: 760, h: 520, spacing: 9 }));
  // beach umbrellas + towels
  const ums = scatter(T, R, 40, { minD: HW + 6, maxD: 60, w: 760, h: 520, spacing: 8, extra: (px, pz) => pz > 60 });
  const umCols = ['#ff6f3c', '#ffd23f', '#2f7ff5', '#ff62b0', '#2cbf55'];
  ums.forEach(([px, pz, r], i) => {
    const u = new THREE.Group();
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 3.4, 6), M('#ffffff')); pole.position.y = 1.7; u.add(pole);
    const top = new THREE.Mesh(new THREE.ConeGeometry(2.4, 1.1, 8), M(umCols[i % umCols.length], { flatShading: true })); top.position.y = 3.4; u.add(top);
    const towel = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 2.6), M(umCols[(i + 2) % umCols.length])); towel.rotation.x = -Math.PI / 2; towel.position.set(1.8, 0.02, 0.5); u.add(towel);
    u.position.set(px, 0, pz); u.rotation.y = r * 6; group.add(u);
  });
  // beach huts
  for (const [px, pz, r] of scatter(T, R, 10, { minD: HW + 14, maxD: 50, w: 760, h: 520, spacing: 25 })) {
    const h = new THREE.Group();
    const b = new THREE.Mesh(new THREE.BoxGeometry(5, 3.4, 4), M(['#5ec8e5', '#ffb3c7', '#fff1b6', '#b5e48c'][Math.floor(r * 4)])); b.position.y = 1.7; h.add(b);
    const rf = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 4.2, 2, 4, 1), M('#c0392b', { flatShading: true })); rf.position.y = 4.4; rf.rotation.y = Math.PI / 4; h.add(rf);
    h.position.set(px, 0, pz); h.rotation.y = r * 6; group.add(h);
  }
  // lighthouse on a rocky point
  const lh = new THREE.Group();
  const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(14, 0), M('#8b8478', { flatShading: true })); rock.scale.y = 0.45; lh.add(rock);
  for (let k = 0; k < 6; k++) { const seg = new THREE.Mesh(new THREE.CylinderGeometry(3.2 - k * 0.25, 3.45 - k * 0.25, 5, 16), M(k % 2 ? '#ffffff' : '#e63946')); seg.position.y = 6 + k * 5; lh.add(seg); }
  const lamp = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.2, 3, 12), new THREE.MeshStandardMaterial({ color: '#fff6c8', emissive: '#ffe57a', emissiveIntensity: 1 })); lamp.position.y = 37; lh.add(lamp);
  const cap = new THREE.Mesh(new THREE.ConeGeometry(2.8, 3, 12), M('#2b2b33')); cap.position.y = 40; lh.add(cap);
  lh.position.set(330, 0, 225); group.add(lh);
  // jetty + boats
  const jetty = new THREE.Mesh(new THREE.BoxGeometry(5, 0.5, 70), M('#8a5a34')); jetty.position.set(-60, 0.4, 245); group.add(jetty);
  boats(group, T, R, 14, [800, 300], 30);
  group.userData.boats.children.forEach(b => { b.position.z = 230 + Math.abs(b.position.z) * 0.6; });
  hillsRing(group, R, '#7aa865', 700, 22, 40, 120);
}
