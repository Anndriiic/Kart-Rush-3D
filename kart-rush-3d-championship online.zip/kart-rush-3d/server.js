// Kart Rush 3D Championship - party racing server (zero dependencies, Node 18+)
// Run:  node server.js        then open http://localhost:3000/host on the big screen.
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const QRCode = require('./vendor/QRCode');
const QRErrorCorrectLevel = require('./vendor/QRCode/QRErrorCorrectLevel');

const PORT = parseInt(process.env.PORT, 10) || 3000;
const PUBLIC_URL = process.env.PUBLIC_URL || process.env.RENDER_EXTERNAL_URL || ''; // set automatically when hosted online
const MAX_PLAYERS = 32;
const PUB = path.join(__dirname, 'public');

// ---------- helpers ----------
function lanAddresses() {
  const out = [];
  const ifs = os.networkInterfaces();
  for (const name of Object.keys(ifs)) {
    for (const a of ifs[name] || []) {
      if (a.family === 'IPv4' && !a.internal) out.push(a.address);
    }
  }
  // Prefer typical home/office ranges first
  out.sort((a, b) => score(b) - score(a));
  return out;
  function score(ip) {
    if (ip.startsWith('192.168.')) return 3;
    if (ip.startsWith('10.')) return 2;
    if (/^172\.(1[6-9]|2\d|3[01])\./.test(ip)) return 1;
    return 0;
  }
}
function baseUrl(origin) {
  if (PUBLIC_URL) return PUBLIC_URL.replace(/\/$/, '');
  // when hosted online, the big screen's own address is the address players should use
  if (origin && /^https?:\/\/[^/]+$/.test(origin) && !/\/\/(localhost|127\.0\.0\.1|\[::1\])(:|$)/.test(origin)) return origin;
  const ip = lanAddresses()[0] || 'localhost';
  return `http://${ip}:${PORT}`;
}
function qrMatrix(text) {
  const q = new QRCode(-1, QRErrorCorrectLevel.M);
  q.addData(text);
  q.make();
  const n = q.getModuleCount();
  const rows = [];
  for (let r = 0; r < n; r++) {
    let s = '';
    for (let c = 0; c < n; c++) s += q.isDark(r, c) ? '1' : '0';
    rows.push(s);
  }
  return rows;
}
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; // no I / O
function newCode() {
  let c;
  do {
    c = '';
    for (let i = 0; i < 4; i++) c += CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)];
  } while (rooms.has(c));
  return c;
}

// ---------- static files ----------
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.json': 'application/json',
};
const server = http.createServer((req, res) => {
  let p = decodeURIComponent((req.url || '/').split('?')[0]);
  if (p === '/health') { res.writeHead(200, { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store' }); return res.end('ok'); }
  if (p === '/' || p === '/play') p = '/controller.html';
  else if (p === '/host' || p === '/host/') p = '/host.html';
  const file = path.normalize(path.join(PUB, p));
  if (!file.startsWith(PUB)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(data);
  });
});

// ---------- minimal WebSocket (RFC 6455) ----------
const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
server.on('upgrade', (req, socket) => {
  const key = req.headers['sec-websocket-key'];
  if (!key || (req.headers.upgrade || '').toLowerCase() !== 'websocket') { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n' +
    `Sec-WebSocket-Accept: ${accept}\r\n\r\n`);
  socket.setNoDelay(true);
  const conn = makeConn(socket);
  allConns.add(conn);
  onConnection(conn);
});

function makeConn(socket) {
  let buf = Buffer.alloc(0);
  let fragments = [];
  const conn = {
    socket, alive: true, handlers: {},
    on(ev, fn) { this.handlers[ev] = fn; },
    send(obj) {
      if (!this.alive) return;
      const payload = Buffer.from(typeof obj === 'string' ? obj : JSON.stringify(obj));
      const len = payload.length;
      let header;
      if (len < 126) { header = Buffer.from([0x81, len]); }
      else if (len < 65536) { header = Buffer.alloc(4); header[0] = 0x81; header[1] = 126; header.writeUInt16BE(len, 2); }
      else { header = Buffer.alloc(10); header[0] = 0x81; header[1] = 127; header.writeBigUInt64BE(BigInt(len), 2); }
      try { socket.write(Buffer.concat([header, payload])); } catch (e) { /* ignore */ }
    },
    close() {
      if (!this.alive) return;
      this.alive = false;
      try { socket.write(Buffer.from([0x88, 0])); socket.end(); } catch (e) { /* ignore */ }
      if (this.handlers.close) this.handlers.close();
    },
  };
  socket.on('data', (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 2) {
      const fin = (buf[0] & 0x80) !== 0;
      const op = buf[0] & 0x0f;
      const masked = (buf[1] & 0x80) !== 0;
      let len = buf[1] & 0x7f;
      let off = 2;
      if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
      if (len > 1 << 20) { conn.close(); socket.destroy(); return; } // 1MB guard
      const maskOff = off; if (masked) off += 4;
      if (buf.length < off + len) return;
      let payload = buf.subarray(off, off + len);
      if (masked) {
        const m = buf.subarray(maskOff, maskOff + 4);
        payload = Buffer.from(payload);
        for (let i = 0; i < payload.length; i++) payload[i] ^= m[i & 3];
      }
      buf = buf.subarray(off + len);
      if (op === 0x8) { conn.close(); return; }
      if (op === 0x9) { // ping -> pong
        const h = Buffer.from([0x8a, payload.length]);
        try { socket.write(Buffer.concat([h, payload])); } catch (e) { /* ignore */ }
        continue;
      }
      if (op === 0xa) continue;
      if (op === 0x1 || op === 0x0) {
        fragments.push(payload);
        if (fin) {
          const text = Buffer.concat(fragments).toString('utf8');
          fragments = [];
          let msg; try { msg = JSON.parse(text); } catch (e) { continue; }
          if (conn.handlers.message) conn.handlers.message(msg);
        }
      }
    }
  });
  const done = () => { if (conn.alive) { conn.alive = false; if (conn.handlers.close) conn.handlers.close(); } };
  socket.on('close', done);
  socket.on('error', done);
  return conn;
}

// ---------- rooms ----------
// room: { code, host: conn, players: Map<id, {id, name, token, conn}> , nextId }
const rooms = new Map();

function onConnection(conn) {
  let role = null, room = null, player = null;

  conn.on('message', (m) => {
    if (!m || typeof m.t !== 'string') return;

    // ----- host -----
    if (m.t === 'host' && !role) {
      role = 'host';
      // allow a host to reclaim its room after a page refresh
      if (typeof m.code === 'string' && rooms.has(m.code) && rooms.get(m.code).host === null && rooms.get(m.code).hostToken === m.token) {
        room = rooms.get(m.code);
        room.host = conn;
        clearTimeout(room.expire);
      } else {
        const code = newCode();
        room = { code, host: conn, hostToken: String(m.token || ''), players: new Map(), nextId: 1, locked: false };
        rooms.set(code, room);
      }
      const origin = typeof m.origin === 'string' ? m.origin.slice(0, 200) : '';
      const base = baseUrl(origin);
      const joinUrl = `${base}/?r=${room.code}`;
      conn.send({ t: 'room', code: room.code, url: base, joinUrl, qr: qrMatrix(joinUrl), max: MAX_PLAYERS,
        players: [...room.players.values()].map(p => ({ id: p.id, name: p.name, online: !!p.conn })) });
      log(`Room ${room.code} opened`);
      return;
    }
    if (role === 'host') {
      if (m.t === 'to' && room.players.has(m.id)) { const p = room.players.get(m.id); if (p.conn) p.conn.send(m.msg); }
      else if (m.t === 'all') { for (const p of room.players.values()) if (p.conn) p.conn.send(m.msg); }
      else if (m.t === 'lock') { room.locked = !!m.v; }
      else if (m.t === 'kick' && room.players.has(m.id)) {
        const p = room.players.get(m.id);
        room.players.delete(m.id);
        if (p.conn) { p.conn.send({ t: 'kicked' }); p.conn.close(); }
      }
      return;
    }

    // ----- player -----
    if (m.t === 'join' && !role) {
      const code = String(m.code || '').toUpperCase().trim();
      const r = rooms.get(code);
      if (!r || !r.host) { conn.send({ t: 'err', msg: 'Room not found. Check the code on the big screen.' }); return; }
      const name = String(m.name || '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 12) || 'Racer';
      const token = String(m.token || '').slice(0, 64);
      // rejoin?
      let p = token ? [...r.players.values()].find(x => x.token === token) : null;
      if (p) {
        if (p.conn && p.conn !== conn) { try { p.conn.close(); } catch (e) { /* ignore */ } }
        p.conn = conn; p.name = name;
        r.host.send({ t: 'back', id: p.id, name });
      } else {
        if (r.players.size >= MAX_PLAYERS) { conn.send({ t: 'err', msg: `This room is full (${MAX_PLAYERS} racers). Ask the host about the next event!` }); return; }
        if (r.locked) { conn.send({ t: 'err', msg: 'Registration is closed — the championship has started.' }); return; }
        p = { id: r.nextId++, name, token, conn };
        r.players.set(p.id, p);
        r.host.send({ t: 'join', id: p.id, name });
      }
      role = 'player'; room = r; player = p;
      conn.send({ t: 'joined', id: p.id, code });
      return;
    }
    if (role === 'player' && room && room.host) {
      if (m.t === 'in' || m.t === 'use' || m.t === 'ready' || m.t === 'ping' || m.t === 'custom' || m.t === 'horn') {
        m.id = player.id;
        room.host.send(m);
      }
    }
  });

  conn.on('close', () => {
    if (role === 'host' && room && room.host === conn) {
      room.host = null;
      // keep the room for 60s in case the host page is refreshed
      room.expire = setTimeout(() => {
        for (const p of room.players.values()) if (p.conn) p.conn.send({ t: 'hostgone' });
        rooms.delete(room.code);
        log(`Room ${room.code} closed`);
      }, 60000);
      for (const p of room.players.values()) if (p.conn) p.conn.send({ t: 'hostwait' });
    } else if (role === 'player' && room && player && player.conn === conn) {
      player.conn = null;
      if (room.host) room.host.send({ t: 'drop', id: player.id });
    }
  });
}

const allConns = new Set();
setInterval(() => {
  for (const c of allConns) { if (!c.alive) { allConns.delete(c); continue; } try { c.socket.write(Buffer.from([0x89, 0])); } catch (e) { /* ignore */ } }
}, 25000);

function log(s) { console.log(`[${new Date().toLocaleTimeString()}] ${s}`); }

server.listen(PORT, '0.0.0.0', () => {
  const ips = lanAddresses();
  console.log('\n  KART RUSH 3D CHAMPIONSHIP is running!\n');
  console.log(`  Big screen (open on this laptop):  http://localhost:${PORT}/host`);
  if (process.env.RENDER) console.log('  Running online — open https://<your-app>.onrender.com/host on the big screen.');
  else if (PUBLIC_URL) console.log(`  Players join at:                   ${PUBLIC_URL}`);
  else if (ips.length) {
    console.log(`  Players join at:                   http://${ips[0]}:${PORT}`);
    if (ips.length > 1) console.log(`  (other addresses: ${ips.slice(1).map(i => `http://${i}:${PORT}`).join(', ')})`);
  } else console.log('  No network found - connect this laptop to Wi-Fi so phones can reach it.');
  console.log('\n  Press Ctrl+C to stop.\n');
});
