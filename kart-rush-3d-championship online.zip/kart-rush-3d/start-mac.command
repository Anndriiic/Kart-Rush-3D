#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Please install the LTS version from https://nodejs.org and try again."
  read -p "Press Enter to close..."
  exit 1
fi
(sleep 1.5; open "http://localhost:3000/host") &
node server.js
