@echo off
title Kart Rush 3D Championship
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Please install the LTS version from https://nodejs.org and try again.
  pause
  exit /b
)
start "" /b cmd /c "ping -n 3 127.0.0.1 >nul & start http://localhost:3000/host"
node server.js
pause
